from __future__ import annotations

import argparse
import hashlib
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import signal


FS = 48_000
DEFAULT_SEED = 20260702


@dataclass(frozen=True)
class Scheme:
    name: str
    modulation: str
    bits_per_symbol: int
    symbol_ms: float
    tones: tuple[float, ...] = ()
    row_tones: tuple[float, ...] = ()
    col_tones: tuple[float, ...] = ()
    codec: str = "none"
    note: str = ""

    @property
    def baud(self) -> float:
        return 1000.0 / self.symbol_ms

    @property
    def raw_bitrate(self) -> float:
        return self.baud * self.bits_per_symbol

    @property
    def used_tones(self) -> tuple[float, ...]:
        if self.modulation == "dtmf":
            return tuple(sorted(set(self.row_tones + self.col_tones)))
        return self.tones

    @property
    def goertzel_bins(self) -> int:
        if self.modulation == "dtmf":
            return len(self.row_tones) + len(self.col_tones)
        return len(self.tones)


def default_schemes() -> list[Scheme]:
    return [
        Scheme(
            name="OOK_1800",
            modulation="ook",
            bits_per_symbol=1,
            symbol_ms=20.0,
            tones=(1800.0,),
            note="1 carrier, energy threshold",
        ),
        Scheme(
            name="2FSK",
            modulation="fsk",
            bits_per_symbol=1,
            symbol_ms=20.0,
            tones=(1600.0, 2000.0),
            note="low-rate robust baseline",
        ),
        Scheme(
            name="4FSK",
            modulation="fsk",
            bits_per_symbol=2,
            symbol_ms=20.0,
            tones=(1400.0, 1700.0, 2000.0, 2300.0),
            note="balanced speed and bandwidth",
        ),
        Scheme(
            name="4FSK_Hamming74",
            modulation="fsk",
            bits_per_symbol=2,
            symbol_ms=20.0,
            tones=(1400.0, 1700.0, 2000.0, 2300.0),
            codec="hamming74",
            note="4FSK with single-bit error correction per 7 coded bits",
        ),
        Scheme(
            name="8FSK",
            modulation="fsk",
            bits_per_symbol=3,
            symbol_ms=24.0,
            tones=(1200.0, 1450.0, 1700.0, 1950.0, 2200.0, 2450.0, 2700.0, 2950.0),
            note="higher throughput, wider occupied band",
        ),
        Scheme(
            name="DTMF",
            modulation="dtmf",
            bits_per_symbol=4,
            symbol_ms=40.0,
            row_tones=(697.0, 770.0, 852.0, 941.0),
            col_tones=(1209.0, 1336.0, 1477.0, 1633.0),
            note="dual-tone 16-symbol keypad style coding",
        ),
    ]


def hamming74_encode(bits: np.ndarray) -> np.ndarray:
    pad = (-len(bits)) % 4
    if pad:
        bits = np.concatenate([bits, np.zeros(pad, dtype=np.uint8)])
    n = bits.reshape(-1, 4)
    d1, d2, d3, d4 = n[:, 0], n[:, 1], n[:, 2], n[:, 3]
    p1 = d1 ^ d2 ^ d4
    p2 = d1 ^ d3 ^ d4
    p3 = d2 ^ d3 ^ d4
    code = np.column_stack([p1, p2, d1, p3, d2, d3, d4]).astype(np.uint8)
    return code.reshape(-1)


def hamming74_decode(bits: np.ndarray, output_len: int) -> np.ndarray:
    usable = (len(bits) // 7) * 7
    blocks = bits[:usable].reshape(-1, 7).copy()
    if len(blocks) == 0:
        return np.zeros(output_len, dtype=np.uint8)

    b = blocks
    s1 = b[:, 0] ^ b[:, 2] ^ b[:, 4] ^ b[:, 6]
    s2 = b[:, 1] ^ b[:, 2] ^ b[:, 5] ^ b[:, 6]
    s3 = b[:, 3] ^ b[:, 4] ^ b[:, 5] ^ b[:, 6]
    err_pos = s1 + 2 * s2 + 4 * s3
    for row, pos in enumerate(err_pos):
        if 1 <= pos <= 7:
            blocks[row, int(pos) - 1] ^= 1

    data = blocks[:, [2, 4, 5, 6]].reshape(-1).astype(np.uint8)
    if len(data) < output_len:
        data = np.concatenate([data, np.zeros(output_len - len(data), dtype=np.uint8)])
    return data[:output_len]


def encode_bits(bits: np.ndarray, codec: str) -> np.ndarray:
    if codec == "none":
        return bits.astype(np.uint8)
    if codec == "hamming74":
        return hamming74_encode(bits.astype(np.uint8))
    raise ValueError(f"unknown codec: {codec}")


def decode_bits(bits: np.ndarray, codec: str, output_len: int) -> np.ndarray:
    if codec == "none":
        if len(bits) < output_len:
            bits = np.concatenate([bits, np.zeros(output_len - len(bits), dtype=np.uint8)])
        return bits[:output_len].astype(np.uint8)
    if codec == "hamming74":
        return hamming74_decode(bits.astype(np.uint8), output_len)
    raise ValueError(f"unknown codec: {codec}")


def bits_to_symbols(bits: np.ndarray, bits_per_symbol: int) -> tuple[np.ndarray, int]:
    pad = (-len(bits)) % bits_per_symbol
    padded = bits
    if pad:
        padded = np.concatenate([bits, np.zeros(pad, dtype=np.uint8)])
    weights = 2 ** np.arange(bits_per_symbol - 1, -1, -1, dtype=np.uint16)
    symbols = padded.reshape(-1, bits_per_symbol).dot(weights).astype(np.int16)
    return symbols, len(padded)


def symbols_to_bits(symbols: np.ndarray, bits_per_symbol: int, bit_len: int) -> np.ndarray:
    shifts = np.arange(bits_per_symbol - 1, -1, -1, dtype=np.int16)
    bits = ((symbols[:, None] >> shifts) & 1).astype(np.uint8).reshape(-1)
    if len(bits) < bit_len:
        bits = np.concatenate([bits, np.zeros(bit_len - len(bits), dtype=np.uint8)])
    return bits[:bit_len]


def edge_envelope(n: int, fs: int) -> np.ndarray:
    ramp = min(max(int(0.002 * fs), 1), n // 6)
    env = np.ones(n, dtype=np.float64)
    if ramp > 1:
        r = 0.5 - 0.5 * np.cos(np.linspace(0.0, math.pi, ramp))
        env[:ramp] = r
        env[-ramp:] = r[::-1]
    return env


def modulate(scheme: Scheme, symbols: np.ndarray, fs: int, tx_freq_offset_hz: float = 0.0) -> np.ndarray:
    n = int(round(fs * scheme.symbol_ms / 1000.0))
    t = np.arange(n) / fs
    env = edge_envelope(n, fs)
    out = np.zeros(n * len(symbols), dtype=np.float64)

    if scheme.modulation in {"ook", "fsk"}:
        phases = {freq: 0.0 for freq in scheme.tones}
        for i, sym in enumerate(symbols):
            start = i * n
            if scheme.modulation == "ook" and sym == 0:
                continue
            freq = scheme.tones[0] if scheme.modulation == "ook" else scheme.tones[int(sym)]
            freq_tx = freq + tx_freq_offset_hz
            phase = phases[freq]
            seg = np.sin(phase + 2.0 * math.pi * freq_tx * t)
            phases[freq] = (phase + 2.0 * math.pi * freq_tx * n / fs) % (2.0 * math.pi)
            out[start : start + n] = seg * env
    elif scheme.modulation == "dtmf":
        for i, sym in enumerate(symbols):
            row = int(sym) // 4
            col = int(sym) % 4
            f1 = scheme.row_tones[row] + tx_freq_offset_hz
            f2 = scheme.col_tones[col] + tx_freq_offset_hz
            seg = 0.5 * np.sin(2.0 * math.pi * f1 * t) + 0.5 * np.sin(2.0 * math.pi * f2 * t)
            out[i * n : (i + 1) * n] = seg * env
    else:
        raise ValueError(f"unknown modulation: {scheme.modulation}")

    rms = math.sqrt(float(np.mean(out * out))) if len(out) else 1.0
    return 0.8 * out / max(rms, 1e-12)


def add_channel(
    x: np.ndarray,
    fs: int,
    rng: np.random.Generator,
    snr_db: float | None = None,
    jammer_jsr_db: float | None = None,
    jammer_freq_hz: float | None = None,
    clip_level: float | None = None,
) -> np.ndarray:
    y = x.copy()
    signal_power = float(np.mean(x * x))
    t = np.arange(len(x)) / fs

    if jammer_jsr_db is not None and jammer_freq_hz is not None:
        jammer_power = signal_power * 10.0 ** (jammer_jsr_db / 10.0)
        amp = math.sqrt(2.0 * jammer_power)
        phase = rng.uniform(0.0, 2.0 * math.pi)
        y += amp * np.sin(2.0 * math.pi * jammer_freq_hz * t + phase)

    if snr_db is not None:
        noise_power = signal_power / (10.0 ** (snr_db / 10.0))
        y += rng.normal(0.0, math.sqrt(noise_power), size=len(x))

    if clip_level is not None:
        y = np.clip(y, -clip_level, clip_level)
    return y


def reference_bank(freqs: Iterable[float], n: int, fs: int) -> tuple[np.ndarray, np.ndarray]:
    t = np.arange(n) / fs
    freqs = np.asarray(list(freqs), dtype=np.float64)
    sin_ref = np.sin(2.0 * math.pi * freqs[:, None] * t[None, :])
    cos_ref = np.cos(2.0 * math.pi * freqs[:, None] * t[None, :])
    win = edge_envelope(n, fs)
    return sin_ref * win, cos_ref * win


def tone_energies(y: np.ndarray, freqs: Iterable[float], n: int, fs: int) -> np.ndarray:
    sin_ref, cos_ref = reference_bank(freqs, n, fs)
    usable = (len(y) // n) * n
    frames = y[:usable].reshape(-1, n)
    s = frames @ sin_ref.T
    c = frames @ cos_ref.T
    return s * s + c * c


def demodulate(scheme: Scheme, y: np.ndarray, expected_symbols: int, fs: int) -> np.ndarray:
    n = int(round(fs * scheme.symbol_ms / 1000.0))
    if scheme.modulation == "ook":
        energy = tone_energies(y, scheme.tones, n, fs)[:expected_symbols, 0]
        sorted_energy = np.sort(energy)
        half = max(1, len(sorted_energy) // 2)
        lo = float(np.median(sorted_energy[:half]))
        hi = float(np.median(sorted_energy[half:]))
        threshold = 0.5 * (lo + hi)
        return (energy > threshold).astype(np.int16)

    if scheme.modulation == "fsk":
        energy = tone_energies(y, scheme.tones, n, fs)[:expected_symbols, :]
        return np.argmax(energy, axis=1).astype(np.int16)

    if scheme.modulation == "dtmf":
        row_energy = tone_energies(y, scheme.row_tones, n, fs)[:expected_symbols, :]
        col_energy = tone_energies(y, scheme.col_tones, n, fs)[:expected_symbols, :]
        rows = np.argmax(row_energy, axis=1)
        cols = np.argmax(col_energy, axis=1)
        return (4 * rows + cols).astype(np.int16)

    raise ValueError(f"unknown modulation: {scheme.modulation}")


def occupied_bandwidth_99(x: np.ndarray, fs: int) -> tuple[float, float, float]:
    nperseg = min(8192, max(1024, int(2 ** math.floor(math.log2(max(1024, len(x) // 8))))))
    freqs, psd = signal.welch(x, fs=fs, nperseg=nperseg)
    total = float(np.sum(psd))
    if total <= 0.0:
        return 0.0, 0.0, 0.0
    cum = np.cumsum(psd) / total
    lo = freqs[int(np.searchsorted(cum, 0.005))]
    hi = freqs[min(int(np.searchsorted(cum, 0.995)), len(freqs) - 1)]
    return float(hi - lo), float(lo), float(hi)


def nominal_bandwidth(scheme: Scheme) -> float:
    tones = scheme.used_tones
    if not tones:
        return 0.0
    return (max(tones) - min(tones)) + 2.0 * scheme.baud


def useful_bitrate(scheme: Scheme, payload_bits: int) -> float:
    coded = encode_bits(np.zeros(payload_bits, dtype=np.uint8), scheme.codec)
    symbols, _ = bits_to_symbols(coded, scheme.bits_per_symbol)
    duration = len(symbols) * scheme.symbol_ms / 1000.0
    return payload_bits / duration


def message_duration_s(scheme: Scheme, payload_bits: int) -> float:
    coded = encode_bits(np.zeros(payload_bits, dtype=np.uint8), scheme.codec)
    symbols, _ = bits_to_symbols(coded, scheme.bits_per_symbol)
    return len(symbols) * scheme.symbol_ms / 1000.0


def worst_jammer_freq(scheme: Scheme) -> float:
    tones = scheme.used_tones
    return tones[len(tones) // 2]


def simulate_once(
    scheme: Scheme,
    payload_bits: int,
    rng: np.random.Generator,
    fs: int = FS,
    snr_db: float | None = None,
    jammer_jsr_db: float | None = None,
    jammer_freq_hz: float | None = None,
    tx_freq_offset_hz: float = 0.0,
) -> dict[str, float | int | bool]:
    src_bits = rng.integers(0, 2, size=payload_bits, dtype=np.uint8)
    coded_bits = encode_bits(src_bits, scheme.codec)
    tx_symbols, coded_bit_len = bits_to_symbols(coded_bits, scheme.bits_per_symbol)
    x = modulate(scheme, tx_symbols, fs, tx_freq_offset_hz=tx_freq_offset_hz)
    y = add_channel(
        x,
        fs,
        rng,
        snr_db=snr_db,
        jammer_jsr_db=jammer_jsr_db,
        jammer_freq_hz=jammer_freq_hz,
    )
    rx_symbols = demodulate(scheme, y, len(tx_symbols), fs)
    rx_coded_bits = symbols_to_bits(rx_symbols, scheme.bits_per_symbol, coded_bit_len)
    rx_bits = decode_bits(rx_coded_bits, scheme.codec, payload_bits)

    bit_errors = int(np.count_nonzero(src_bits != rx_bits))
    sym_errors = int(np.count_nonzero(tx_symbols != rx_symbols))
    return {
        "bit_errors": bit_errors,
        "bits": payload_bits,
        "symbol_errors": sym_errors,
        "symbols": int(len(tx_symbols)),
        "packet_ok": bit_errors == 0,
    }


def run_condition(
    schemes: list[Scheme],
    payload_bits: int,
    trials: int,
    seed: int,
    condition_name: str,
    values: Iterable[float],
    value_name: str,
    snr_db: float | None = None,
    jammer_jsr_db: float | None = None,
    tx_freq_offset_hz: float = 0.0,
) -> pd.DataFrame:
    rows = []
    for scheme in schemes:
        scheme_hash = int(hashlib.sha256(scheme.name.encode("utf-8")).hexdigest()[:8], 16) % 997
        for value in values:
            bit_errors = 0
            bits = 0
            sym_errors = 0
            symbols = 0
            ok = 0
            for trial in range(trials):
                mix_seed = seed + 100_000 * scheme_hash + 1000 * int(round(value * 10 + 5000)) + trial
                rng = np.random.default_rng(mix_seed)
                this_snr = value if value_name == "snr_db" else snr_db
                this_jsr = value if value_name == "jammer_jsr_db" else jammer_jsr_db
                this_off = value if value_name == "tx_freq_offset_hz" else tx_freq_offset_hz
                result = simulate_once(
                    scheme,
                    payload_bits,
                    rng,
                    snr_db=this_snr,
                    jammer_jsr_db=this_jsr,
                    jammer_freq_hz=worst_jammer_freq(scheme) if this_jsr is not None else None,
                    tx_freq_offset_hz=this_off or 0.0,
                )
                bit_errors += int(result["bit_errors"])
                bits += int(result["bits"])
                sym_errors += int(result["symbol_errors"])
                symbols += int(result["symbols"])
                ok += int(bool(result["packet_ok"]))
            rows.append(
                {
                    "condition": condition_name,
                    "scheme": scheme.name,
                    value_name: value,
                    "trials": trials,
                    "ber": bit_errors / max(bits, 1),
                    "ser": sym_errors / max(symbols, 1),
                    "packet_success": ok / max(trials, 1),
                    "bit_errors": bit_errors,
                    "symbol_errors": sym_errors,
                }
            )
    return pd.DataFrame(rows)


def summarize_schemes(schemes: list[Scheme], payload_bits: int, fs: int, seed: int) -> pd.DataFrame:
    rows = []
    rng = np.random.default_rng(seed)
    for scheme in schemes:
        src = rng.integers(0, 2, size=payload_bits, dtype=np.uint8)
        coded = encode_bits(src, scheme.codec)
        symbols, _ = bits_to_symbols(coded, scheme.bits_per_symbol)
        waveform = modulate(scheme, symbols, fs)
        obw, flo, fhi = occupied_bandwidth_99(waveform, fs)
        nbw = nominal_bandwidth(scheme)
        ubit = useful_bitrate(scheme, payload_bits)
        rows.append(
            {
                "scheme": scheme.name,
                "modulation": scheme.modulation,
                "codec": scheme.codec,
                "baud": scheme.baud,
                "raw_bitrate_bps": scheme.raw_bitrate,
                "useful_bitrate_bps_for_payload": ubit,
                "message_duration_s": message_duration_s(scheme, payload_bits),
                "nominal_bandwidth_hz": nbw,
                "occupied_bandwidth_99_hz": obw,
                "occupied_low_hz": flo,
                "occupied_high_hz": fhi,
                "spectral_efficiency_bps_per_hz": ubit / max(nbw, 1e-9),
                "goertzel_bins": scheme.goertzel_bins,
                "tones_hz": " ".join(f"{f:g}" for f in scheme.used_tones),
                "note": scheme.note,
            }
        )
    return pd.DataFrame(rows)


def waveform_previews(schemes: list[Scheme], fs: int) -> dict[str, dict[str, object]]:
    previews: dict[str, dict[str, object]] = {}
    for scheme in schemes:
        if scheme.modulation == "ook":
            base_symbols = np.array([0, 1, 1, 0, 1, 0, 0, 1, 1, 1, 0, 1], dtype=np.int16)
        elif scheme.modulation == "dtmf":
            base_symbols = np.arange(16, dtype=np.int16)
        else:
            base_symbols = np.arange(len(scheme.tones), dtype=np.int16)
            base_symbols = np.tile(base_symbols, max(2, math.ceil(12 / len(base_symbols))))

        symbols = base_symbols[: min(len(base_symbols), 16)]
        x = modulate(scheme, symbols, fs)
        preview_len = min(len(x), int(0.32 * fs))
        x = x[:preview_len]

        max_points = 720
        step = max(1, len(x) // max_points)
        x_ds = x[::step]
        t_ms = np.arange(0, len(x), step)[: len(x_ds)] / fs * 1000.0

        win = signal.windows.hann(len(x), sym=False)
        spec = np.abs(np.fft.rfft(x * win))
        freqs = np.fft.rfftfreq(len(x), 1.0 / fs)
        mask = (freqs >= 300.0) & (freqs <= 3600.0)
        freqs = freqs[mask]
        spec = spec[mask]
        spec_db = 20.0 * np.log10(spec / max(float(np.max(spec)), 1e-12) + 1e-12)
        spec_db = np.maximum(spec_db, -72.0)
        spec_step = max(1, len(freqs) // 560)

        previews[scheme.name] = {
            "symbols": symbols.astype(int).tolist(),
            "symbol_ms": scheme.symbol_ms,
            "time_ms": np.round(t_ms, 3).tolist(),
            "amplitude": np.round(x_ds, 4).tolist(),
            "freq_hz": np.round(freqs[::spec_step], 1).tolist(),
            "spectrum_db": np.round(spec_db[::spec_step], 2).tolist(),
        }
    return previews


def snr_threshold(df: pd.DataFrame, target_success: float = 0.95) -> dict[str, float | None]:
    out: dict[str, float | None] = {}
    snr_df = df[df["condition"] == "snr_sweep"]
    for scheme, part in snr_df.groupby("scheme"):
        part = part.sort_values("snr_db")
        ok = part[part["packet_success"] >= target_success]
        out[scheme] = None if ok.empty else float(ok.iloc[0]["snr_db"])
    return out


def markdown_table(df: pd.DataFrame) -> str:
    columns = list(df.columns)
    rows = [columns]
    rows.extend([[str(v) for v in row] for row in df.to_numpy()])
    widths = [max(len(str(row[i])) for row in rows) for i in range(len(columns))]

    def fmt(row: list[str]) -> str:
        return "| " + " | ".join(str(row[i]).ljust(widths[i]) for i in range(len(columns))) + " |"

    header = fmt(rows[0])
    sep = "| " + " | ".join("-" * widths[i] for i in range(len(columns))) + " |"
    body = "\n".join(fmt(row) for row in rows[1:])
    return "\n".join([header, sep, body])


def dashboard_html(data_json: str) -> str:
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>声语信使算法选型工作台</title>
  <style>
    :root {{
      color-scheme: light;
      --bg: #f6f7f9;
      --surface: #ffffff;
      --surface-2: #eef3f6;
      --ink: #16202a;
      --muted: #64717f;
      --line: #dbe1e7;
      --blue: #2869d1;
      --teal: #007f75;
      --orange: #c7641a;
      --red: #c43d4b;
      --green: #24805c;
      --violet: #7a4db7;
      --shadow: 0 12px 34px rgba(20, 30, 42, .08);
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      background: var(--bg);
      color: var(--ink);
      font: 14px/1.5 "Microsoft YaHei", "Segoe UI", Arial, sans-serif;
    }}
    button, input, select {{ font: inherit; }}
    .app {{
      min-height: 100vh;
      display: grid;
      grid-template-columns: 300px minmax(0, 1fr);
    }}
    aside {{
      position: sticky;
      top: 0;
      height: 100vh;
      overflow: auto;
      padding: 22px 18px;
      border-right: 1px solid var(--line);
      background: #ffffff;
    }}
    main {{
      min-width: 0;
      padding: 22px 26px 32px;
    }}
    .brand {{
      display: flex;
      align-items: center;
      gap: 10px;
      margin-bottom: 18px;
    }}
    .mark {{
      width: 34px;
      height: 34px;
      border-radius: 8px;
      background: var(--ink);
      color: white;
      display: grid;
      place-items: center;
      font-weight: 800;
    }}
    h1 {{
      font-size: 18px;
      line-height: 1.2;
      margin: 0;
      letter-spacing: 0;
    }}
    .subtle {{ color: var(--muted); }}
    .group {{
      border-top: 1px solid var(--line);
      padding: 16px 0;
    }}
    .group:first-of-type {{ border-top: 0; }}
    .group-title {{
      color: #2b3948;
      font-weight: 700;
      margin-bottom: 10px;
    }}
    label {{
      display: flex;
      justify-content: space-between;
      gap: 10px;
      margin: 13px 0 6px;
      color: #314253;
      font-weight: 650;
    }}
    .value-pill {{
      min-width: 68px;
      text-align: right;
      color: var(--blue);
      font-variant-numeric: tabular-nums;
    }}
    input[type="range"] {{
      width: 100%;
      accent-color: var(--blue);
    }}
    .ticks {{
      display: flex;
      justify-content: space-between;
      color: var(--muted);
      font-size: 12px;
      margin-top: -2px;
    }}
    .tabs {{
      display: flex;
      gap: 6px;
      flex-wrap: wrap;
      margin-bottom: 16px;
    }}
    .tab {{
      border: 1px solid var(--line);
      background: white;
      color: #263442;
      border-radius: 8px;
      padding: 8px 12px;
      cursor: pointer;
    }}
    .tab[aria-selected="true"] {{
      background: var(--ink);
      border-color: var(--ink);
      color: white;
    }}
    .section {{
      display: none;
    }}
    .section.active {{
      display: block;
    }}
    .topline {{
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 16px;
      margin-bottom: 16px;
    }}
    .title-block h2 {{
      margin: 0;
      font-size: 24px;
      line-height: 1.2;
      letter-spacing: 0;
    }}
    .title-block p {{
      margin: 6px 0 0;
      color: var(--muted);
    }}
    .recommend {{
      border: 1px solid var(--line);
      background: white;
      border-radius: 8px;
      padding: 10px 12px;
      min-width: 210px;
      box-shadow: var(--shadow);
    }}
    .recommend .name {{
      font-size: 18px;
      font-weight: 800;
      color: var(--teal);
      margin-top: 2px;
    }}
    .metrics {{
      display: grid;
      grid-template-columns: repeat(4, minmax(120px, 1fr));
      gap: 10px;
      margin-bottom: 16px;
    }}
    .metric {{
      background: white;
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 12px;
    }}
    .metric span {{
      color: var(--muted);
      font-size: 12px;
    }}
    .metric strong {{
      display: block;
      margin-top: 4px;
      font-size: 20px;
      line-height: 1.15;
      font-variant-numeric: tabular-nums;
    }}
    .grid {{
      display: grid;
      grid-template-columns: minmax(0, 1.28fr) minmax(340px, .72fr);
      gap: 14px;
      align-items: start;
    }}
    .panel {{
      background: white;
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 14px;
      box-shadow: var(--shadow);
      min-width: 0;
    }}
    .panel h3 {{
      margin: 0 0 10px;
      font-size: 15px;
      letter-spacing: 0;
    }}
    svg {{
      display: block;
      width: 100%;
      height: auto;
      overflow: visible;
    }}
    .legend {{
      display: flex;
      flex-wrap: wrap;
      gap: 8px 14px;
      margin-top: 10px;
      color: #34495a;
      font-size: 12px;
    }}
    .legend button {{
      display: inline-flex;
      align-items: center;
      gap: 6px;
      border: 0;
      background: transparent;
      padding: 2px 0;
      cursor: pointer;
      color: inherit;
    }}
    .dot {{
      width: 10px;
      height: 10px;
      border-radius: 50%;
      display: inline-block;
    }}
    table {{
      width: 100%;
      border-collapse: collapse;
      font-variant-numeric: tabular-nums;
    }}
    th, td {{
      text-align: left;
      border-bottom: 1px solid var(--line);
      padding: 8px 6px;
      vertical-align: middle;
    }}
    th {{
      color: var(--muted);
      font-size: 12px;
      font-weight: 700;
      white-space: nowrap;
    }}
    tr {{
      cursor: pointer;
    }}
    tr.selected {{
      background: #edf7f6;
    }}
    .status {{
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 46px;
      border-radius: 999px;
      padding: 2px 8px;
      color: white;
      font-weight: 750;
      font-size: 12px;
    }}
    .status.pass {{ background: var(--green); }}
    .status.warn {{ background: var(--orange); }}
    .status.fail {{ background: var(--red); }}
    .chips {{
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }}
    .chip {{
      border: 1px solid var(--line);
      background: var(--surface-2);
      border-radius: 999px;
      padding: 5px 9px;
      color: #2e3e4f;
      font-size: 12px;
    }}
    .button-row {{
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }}
    .choice {{
      border: 1px solid var(--line);
      background: white;
      color: #263442;
      border-radius: 8px;
      padding: 7px 9px;
      cursor: pointer;
      line-height: 1.2;
    }}
    .choice.active {{
      color: white;
      background: var(--blue);
      border-color: var(--blue);
    }}
    .preset-grid {{
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
    }}
    .preset-grid .choice {{
      min-height: 36px;
    }}
    .wave-grid {{
      display: grid;
      grid-template-columns: repeat(3, minmax(190px, 1fr));
      gap: 12px;
      margin-top: 14px;
    }}
    .wave-card {{
      background: white;
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 10px;
      cursor: pointer;
      min-width: 0;
    }}
    .wave-card.selected {{
      border-color: var(--blue);
      box-shadow: 0 0 0 2px rgba(40, 105, 209, .12);
    }}
    .wave-card h4 {{
      margin: 0 0 6px;
      font-size: 13px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
    }}
    .mini-wave {{
      height: 120px;
    }}
    .dual-chart {{
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
    }}
    .wave-meta {{
      margin-top: 8px;
      color: var(--muted);
      font-size: 12px;
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
    }}
    .scheme-detail {{
      display: grid;
      gap: 10px;
    }}
    .kv {{
      display: grid;
      grid-template-columns: 98px minmax(0, 1fr);
      gap: 10px;
      border-bottom: 1px solid var(--line);
      padding-bottom: 8px;
    }}
    .kv:last-child {{ border-bottom: 0; padding-bottom: 0; }}
    .kv span {{ color: var(--muted); }}
    .compare-bars {{
      display: grid;
      gap: 9px;
    }}
    .bar-row {{
      display: grid;
      grid-template-columns: 116px minmax(0, 1fr) 52px;
      gap: 8px;
      align-items: center;
    }}
    .bar-track {{
      height: 10px;
      border-radius: 999px;
      background: #e9edf1;
      overflow: hidden;
    }}
    .bar-fill {{
      height: 100%;
      background: var(--blue);
      border-radius: inherit;
    }}
    .formula {{
      background: #f2f5f7;
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 12px;
      color: #344252;
      white-space: pre-wrap;
    }}
    .tooltip {{
      position: fixed;
      pointer-events: none;
      background: #101820;
      color: white;
      border-radius: 8px;
      padding: 8px 10px;
      font-size: 12px;
      max-width: 260px;
      box-shadow: 0 12px 30px rgba(0,0,0,.18);
      opacity: 0;
      transform: translate(-50%, -115%);
      transition: opacity .12s ease;
      z-index: 20;
    }}
    .tooltip.show {{ opacity: 1; }}
    @media (max-width: 980px) {{
      .app {{ grid-template-columns: 1fr; }}
      aside {{
        position: relative;
        height: auto;
        border-right: 0;
        border-bottom: 1px solid var(--line);
      }}
      main {{ padding: 18px; }}
      .grid {{ grid-template-columns: 1fr; }}
      .metrics {{ grid-template-columns: repeat(2, minmax(120px, 1fr)); }}
      .topline {{ flex-direction: column; }}
      .recommend {{ width: 100%; }}
      .wave-grid {{ grid-template-columns: repeat(2, minmax(180px, 1fr)); }}
      .dual-chart {{ grid-template-columns: 1fr; }}
    }}
    @media (max-width: 560px) {{
      .metrics {{ grid-template-columns: 1fr; }}
      .bar-row {{ grid-template-columns: 96px minmax(0, 1fr) 46px; }}
      th:nth-child(4), td:nth-child(4), th:nth-child(5), td:nth-child(5) {{ display: none; }}
      .preset-grid {{ grid-template-columns: 1fr; }}
      .wave-grid {{ grid-template-columns: 1fr; }}
    }}
  </style>
</head>
<body>
  <div class="app">
    <aside>
      <div class="brand">
        <div class="mark">声</div>
        <div>
          <h1>声语信使算法选型</h1>
          <div class="subtle">48 字符短消息 · 音频声波</div>
        </div>
      </div>

      <div class="group">
        <div class="group-title">算法按钮</div>
        <div class="button-row" id="algorithmButtonsSide"></div>
      </div>

      <div class="group">
        <div class="group-title">一键场景</div>
        <div class="preset-grid">
          <button class="choice" data-preset="quiet">安静教室</button>
          <button class="choice" data-preset="noisy">噪声偏大</button>
          <button class="choice" data-preset="jammed">强干扰</button>
          <button class="choice" data-preset="offset">频偏较大</button>
          <button class="choice" data-preset="reliable">可靠优先</button>
          <button class="choice" data-preset="fast">速度优先</button>
        </div>
      </div>

      <div class="group">
        <div class="group-title">信道条件</div>
        <label for="snr">信噪比 <span class="value-pill" id="snrValue"></span></label>
        <input id="snr" type="range" min="-30" max="12" step="3" value="-15" />
        <div class="ticks"><span>-30</span><span>-9</span><span>12 dB</span></div>

        <label for="jsr">窄带干扰 <span class="value-pill" id="jsrValue"></span></label>
        <input id="jsr" type="range" min="-24" max="6" step="6" value="-12" />
        <div class="ticks"><span>弱</span><span>中</span><span>强</span></div>

        <label for="offset">频率偏差 <span class="value-pill" id="offsetValue"></span></label>
        <input id="offset" type="range" min="0" max="80" step="5" value="10" />
        <div class="ticks"><span>0</span><span>40</span><span>80 Hz</span></div>
      </div>

      <div class="group">
        <div class="group-title">评价权重</div>
        <label for="wReliability">可靠性 <span class="value-pill" id="wReliabilityValue"></span></label>
        <input id="wReliability" type="range" min="0" max="100" step="5" value="50" />

        <label for="wSpeed">传输速度 <span class="value-pill" id="wSpeedValue"></span></label>
        <input id="wSpeed" type="range" min="0" max="100" step="5" value="35" />

        <label for="wSimplicity">实现简单 <span class="value-pill" id="wSimplicityValue"></span></label>
        <input id="wSimplicity" type="range" min="0" max="100" step="5" value="15" />
      </div>

      <div class="group">
        <div class="group-title">当前结论</div>
        <div class="scheme-detail" id="sideConclusion"></div>
      </div>
    </aside>

    <main>
      <div class="tabs" role="tablist">
        <button class="tab" role="tab" aria-selected="true" data-tab="overview">总览</button>
        <button class="tab" role="tab" aria-selected="false" data-tab="waveTab">波形</button>
        <button class="tab" role="tab" aria-selected="false" data-tab="snrTab">信噪比</button>
        <button class="tab" role="tab" aria-selected="false" data-tab="stressTab">抗干扰</button>
        <button class="tab" role="tab" aria-selected="false" data-tab="implementTab">实现</button>
      </div>

      <section id="overview" class="section active">
        <div class="topline">
          <div class="title-block">
            <h2>算法候选与当前场景</h2>
            <p>按可靠性、速度、带宽和 MCU 判决复杂度综合排序。</p>
          </div>
          <div class="recommend">
            <div class="subtle">推荐方案</div>
            <div class="name" id="recommendedName"></div>
            <div class="subtle" id="recommendedReason"></div>
          </div>
        </div>

        <div class="metrics" id="metrics"></div>

        <div class="grid">
          <div class="panel">
            <h3>带宽-速率取舍</h3>
            <svg id="tradeoffChart" viewBox="0 0 760 430" aria-label="bandwidth rate chart"></svg>
            <div class="legend" id="tradeoffLegend"></div>
          </div>
          <div class="panel">
            <h3>当前场景成功率</h3>
            <div class="compare-bars" id="scenarioBars"></div>
          </div>
        </div>

        <div class="panel" style="margin-top:14px;">
          <h3>方案列表</h3>
          <div style="overflow:auto;">
            <table>
              <thead>
                <tr>
                  <th>方案</th>
                  <th>通过</th>
                  <th>成功率</th>
                  <th>时长</th>
                  <th>带宽</th>
                  <th>检测 bin</th>
                  <th>说明</th>
                </tr>
              </thead>
              <tbody id="schemeRows"></tbody>
            </table>
          </div>
        </div>
      </section>

      <section id="waveTab" class="section">
        <div class="topline">
          <div class="title-block">
            <h2>波形与频谱比较</h2>
            <p>每个算法用同一段示例码元生成预览，便于观察码元持续时间、频点分布和频带占用。</p>
          </div>
          <div class="recommend">
            <div class="subtle">当前查看</div>
            <div class="name" id="waveSelectedName"></div>
            <div class="subtle" id="waveSelectedReason"></div>
          </div>
        </div>

        <div class="panel">
          <div class="dual-chart">
            <div>
              <h3>选中算法时域波形</h3>
              <svg id="selectedTimeChart" viewBox="0 0 760 320"></svg>
            </div>
            <div>
              <h3>选中算法频谱</h3>
              <svg id="selectedSpectrumChart" viewBox="0 0 760 320"></svg>
            </div>
          </div>
          <div class="wave-meta" id="waveMeta"></div>
        </div>

        <div class="wave-grid" id="waveCards"></div>
      </section>

      <section id="snrTab" class="section">
        <div class="topline">
          <div class="title-block">
            <h2>信噪比扫描</h2>
            <p>整包成功率按 48 字符消息统计，BER 用于观察误码趋势。</p>
          </div>
        </div>
        <div class="grid">
          <div class="panel">
            <h3>整包成功率</h3>
            <svg id="snrSuccessChart" viewBox="0 0 760 430"></svg>
            <div class="legend" id="snrLegend"></div>
          </div>
          <div class="panel">
            <h3>95% 成功所需 SNR</h3>
            <div class="compare-bars" id="thresholdBars"></div>
          </div>
        </div>
      </section>

      <section id="stressTab" class="section">
        <div class="topline">
          <div class="title-block">
            <h2>抗干扰与频偏</h2>
            <p>窄带干扰取每种方案最不利的候选频点，频偏表示发端频率和收端检测频率的偏差。</p>
          </div>
        </div>
        <div class="grid">
          <div class="panel">
            <h3>窄带干扰</h3>
            <svg id="jammerChart" viewBox="0 0 760 430"></svg>
            <div class="legend" id="jammerLegend"></div>
          </div>
          <div class="panel">
            <h3>频率偏差</h3>
            <svg id="offsetChart" viewBox="0 0 760 430"></svg>
            <div class="legend" id="offsetLegend"></div>
          </div>
        </div>
      </section>

      <section id="implementTab" class="section">
        <div class="topline">
          <div class="title-block">
            <h2>落地实现信息</h2>
            <p>用于把仿真结果转成单片机程序和设计报告参数。</p>
          </div>
        </div>
        <div class="grid">
          <div class="panel">
            <h3>当前选中方案</h3>
            <div class="scheme-detail" id="detailPanel"></div>
          </div>
          <div class="panel">
            <h3>报告可用表述</h3>
            <div class="formula" id="reportText"></div>
          </div>
        </div>
      </section>
    </main>
  </div>
  <div class="tooltip" id="tooltip"></div>

  <script id="simData" type="application/json">{data_json}</script>
  <script>
    const data = JSON.parse(document.getElementById('simData').textContent);
    const colors = ['#2869d1', '#007f75', '#c7641a', '#7a4db7', '#c43d4b', '#24805c', '#6b7c93'];
    const colorByScheme = Object.fromEntries(data.summary.map((d, i) => [d.scheme, colors[i % colors.length]]));
    let selected = data.summary.find(d => d.scheme === '4FSK_Hamming74')?.scheme || data.summary[0].scheme;
    let activeTab = 'overview';
    let activePreset = '';

    const $ = id => document.getElementById(id);
    const fmt = (n, unit = '', digits = 1) => Number.isFinite(Number(n)) ? `${{Number(n).toFixed(digits)}}${{unit}}` : '未达标';
    const pct = n => `${{Math.round(Number(n) * 100)}}%`;
    const nearest = (arr, key, value) => arr.reduce((best, item) => Math.abs(item[key] - value) < Math.abs(best[key] - value) ? item : best, arr[0]);

    function rowsForScheme(source, key, scheme) {{
      return source.filter(d => d.scheme === scheme).sort((a, b) => a[key] - b[key]);
    }}

    function interpolated(source, key, scheme, value, metric) {{
      const rows = rowsForScheme(source, key, scheme);
      if (!rows.length) return 0;
      if (value <= rows[0][key]) return rows[0][metric];
      if (value >= rows[rows.length - 1][key]) return rows[rows.length - 1][metric];
      for (let i = 0; i < rows.length - 1; i++) {{
        const a = rows[i], b = rows[i + 1];
        if (a[key] <= value && value <= b[key]) {{
          const t = (value - a[key]) / (b[key] - a[key]);
          return a[metric] + t * (b[metric] - a[metric]);
        }}
      }}
      return rows[0][metric];
    }}

    function currentState() {{
      const wr = Number($('wReliability').value);
      const ws = Number($('wSpeed').value);
      const wi = Number($('wSimplicity').value);
      const sum = Math.max(wr + ws + wi, 1);
      return {{
        snr: Number($('snr').value),
        jsr: Number($('jsr').value),
        offset: Number($('offset').value),
        wr: wr / sum,
        ws: ws / sum,
        wi: wi / sum
      }};
    }}

    function enrichSchemes() {{
      const s = currentState();
      const maxRate = Math.max(...data.summary.map(d => d.useful_bitrate_bps_for_payload));
      const maxBins = Math.max(...data.summary.map(d => d.goertzel_bins));
      return data.summary.map(d => {{
        const snrSuccess = interpolated(data.snr, 'snr_db', d.scheme, s.snr, 'packet_success');
        const jamSuccess = interpolated(data.jammer, 'jammer_jsr_db', d.scheme, s.jsr, 'packet_success');
        const offSuccess = interpolated(data.offset, 'tx_freq_offset_hz', d.scheme, s.offset, 'packet_success');
        const reliability = 0.58 * snrSuccess + 0.24 * jamSuccess + 0.18 * offSuccess;
        const speed = d.useful_bitrate_bps_for_payload / maxRate;
        const simplicity = 1 - (d.goertzel_bins - 1) / Math.max(maxBins - 1, 1);
        const score = s.wr * reliability + s.ws * speed + s.wi * simplicity;
        return {{...d, snrSuccess, jamSuccess, offSuccess, reliability, speed, simplicity, score}};
      }}).sort((a, b) => b.score - a.score);
    }}

    function statusClass(v) {{
      if (v >= 0.95) return 'pass';
      if (v >= 0.75) return 'warn';
      return 'fail';
    }}

    function statusText(v) {{
      if (v >= 0.95) return '稳';
      if (v >= 0.75) return '临界';
      return '风险';
    }}

    function updateLabels() {{
      $('snrValue').textContent = `${{$('snr').value}} dB`;
      $('jsrValue').textContent = `${{$('jsr').value}} dB`;
      $('offsetValue').textContent = `${{$('offset').value}} Hz`;
      $('wReliabilityValue').textContent = `${{$('wReliability').value}}%`;
      $('wSpeedValue').textContent = `${{$('wSpeed').value}}%`;
      $('wSimplicityValue').textContent = `${{$('wSimplicity').value}}%`;
      document.querySelectorAll('[data-preset]').forEach(btn => btn.classList.toggle('active', btn.dataset.preset === activePreset));
    }}

    function renderAlgorithmButtons() {{
      $('algorithmButtonsSide').innerHTML = data.summary.map(d => `
        <button class="choice ${{d.scheme === selected ? 'active' : ''}}" data-scheme="${{d.scheme}}">${{d.scheme}}</button>
      `).join('');
      document.querySelectorAll('#algorithmButtonsSide button').forEach(btn => {{
        btn.addEventListener('click', () => {{
          selected = btn.dataset.scheme;
          render();
        }});
      }});
    }}

    function applyPreset(name) {{
      activePreset = name;
      const set = (id, value) => {{ $(id).value = value; }};
      if (name === 'quiet') {{
        set('snr', 6); set('jsr', -24); set('offset', 5);
      }} else if (name === 'noisy') {{
        set('snr', -15); set('jsr', -18); set('offset', 10);
      }} else if (name === 'jammed') {{
        set('snr', -12); set('jsr', 0); set('offset', 10);
      }} else if (name === 'offset') {{
        set('snr', -9); set('jsr', -12); set('offset', 40);
      }} else if (name === 'reliable') {{
        set('wReliability', 70); set('wSpeed', 10); set('wSimplicity', 20);
      }} else if (name === 'fast') {{
        set('wReliability', 30); set('wSpeed', 55); set('wSimplicity', 15);
      }}
      render();
    }}

    function renderMetrics(ranked) {{
      const best = ranked[0];
      $('recommendedName').textContent = best.scheme;
      $('recommendedReason').textContent = `综合评分 ${{Math.round(best.score * 100)}}，当前场景成功率 ${{pct(best.snrSuccess)}}`;
      const threshold = data.thresholds[best.scheme];
      const items = [
        ['当前成功率', pct(best.snrSuccess), '按 SNR 条件估算'],
        ['消息时长', fmt(best.message_duration_s, ' s', 2), '48 字符英文消息'],
        ['有效速率', fmt(best.useful_bitrate_bps_for_payload, ' bps', 0), '扣除纠错开销'],
        ['95% SNR', threshold == null ? '未达标' : fmt(threshold, ' dB', 0), '整包成功率门槛']
      ];
      $('metrics').innerHTML = items.map(([k, v, h]) => `<div class="metric"><span>${{k}}</span><strong>${{v}}</strong><span>${{h}}</span></div>`).join('');
      $('sideConclusion').innerHTML = `
        <div class="kv"><span>优先方案</span><strong>${{best.scheme}}</strong></div>
        <div class="kv"><span>通过状态</span><strong>${{statusText(best.snrSuccess)}} · ${{pct(best.snrSuccess)}}</strong></div>
        <div class="kv"><span>实现代价</span><strong>${{best.goertzel_bins}} 个检测频点</strong></div>
      `;
    }}

    function renderBars(ranked) {{
      $('scenarioBars').innerHTML = ranked.map(d => `
        <div class="bar-row" title="${{d.scheme}}">
          <strong>${{d.scheme}}</strong>
          <div class="bar-track"><div class="bar-fill" style="width:${{Math.round(d.snrSuccess * 100)}}%; background:${{colorByScheme[d.scheme]}}"></div></div>
          <span>${{pct(d.snrSuccess)}}</span>
        </div>
      `).join('');
      const maxThr = Math.max(...Object.values(data.thresholds).filter(v => v !== null), 1);
      $('thresholdBars').innerHTML = data.summary.map(d => {{
        const t = data.thresholds[d.scheme];
        const width = t == null ? 100 : Math.max(6, 100 * t / maxThr);
        return `
          <div class="bar-row">
            <strong>${{d.scheme}}</strong>
            <div class="bar-track"><div class="bar-fill" style="width:${{width}}%; background:${{t == null ? '#c43d4b' : colorByScheme[d.scheme]}}"></div></div>
            <span>${{t == null ? '无' : fmt(t, '', 0)}}</span>
          </div>
        `;
      }}).join('');
    }}

    function renderTable(ranked) {{
      $('schemeRows').innerHTML = ranked.map(d => `
        <tr class="${{d.scheme === selected ? 'selected' : ''}}" data-scheme="${{d.scheme}}">
          <td><strong>${{d.scheme}}</strong></td>
          <td><span class="status ${{statusClass(d.snrSuccess)}}">${{statusText(d.snrSuccess)}}</span></td>
          <td>${{pct(d.snrSuccess)}}</td>
          <td>${{fmt(d.message_duration_s, ' s', 2)}}</td>
          <td>${{fmt(d.nominal_bandwidth_hz, ' Hz', 0)}}</td>
          <td>${{d.goertzel_bins}}</td>
          <td>${{d.note}}</td>
        </tr>
      `).join('');
      document.querySelectorAll('#schemeRows tr').forEach(row => {{
        row.addEventListener('click', () => {{
          selected = row.dataset.scheme;
          render();
        }});
      }});
    }}

    function chartScales(valuesX, valuesY, w, h, pad) {{
      const xmin = Math.min(...valuesX), xmax = Math.max(...valuesX);
      const ymin = Math.min(...valuesY), ymax = Math.max(...valuesY);
      const xpad = (xmax - xmin || 1) * .08;
      const ypad = (ymax - ymin || 1) * .10;
      const scale = {{
        xmin: xmin - xpad,
        xmax: xmax + xpad,
        ymin: ymin - ypad,
        ymax: ymax + ypad
      }};
      scale.x = v => pad.l + (v - scale.xmin) / Math.max(scale.xmax - scale.xmin, 1e-9) * (w - pad.l - pad.r);
      scale.y = v => h - pad.b - (v - scale.ymin) / Math.max(scale.ymax - scale.ymin, 1e-9) * (h - pad.t - pad.b);
      return scale;
    }}

    function axes(svg, scale, w, h, pad, xLabel, yLabel, yPct = false, xFmt = null, yFmt = null) {{
      const xTicks = 5, yTicks = 5;
      let g = `<line x1="${{pad.l}}" y1="${{h-pad.b}}" x2="${{w-pad.r}}" y2="${{h-pad.b}}" stroke="#aeb8c2"/>
               <line x1="${{pad.l}}" y1="${{pad.t}}" x2="${{pad.l}}" y2="${{h-pad.b}}" stroke="#aeb8c2"/>`;
      for (let i = 0; i <= xTicks; i++) {{
        const v = scale.xmin + (scale.xmax - scale.xmin) * i / xTicks;
        const x = scale.x(v);
        const label = xFmt ? xFmt(v) : Math.round(v);
        g += `<line x1="${{x}}" y1="${{pad.t}}" x2="${{x}}" y2="${{h-pad.b}}" stroke="#edf1f4"/>
              <text x="${{x}}" y="${{h-pad.b+24}}" text-anchor="middle" fill="#64717f" font-size="12">${{label}}</text>`;
      }}
      for (let i = 0; i <= yTicks; i++) {{
        const v = scale.ymin + (scale.ymax - scale.ymin) * i / yTicks;
        const y = scale.y(v);
        const label = yFmt ? yFmt(v) : (yPct ? `${{Math.round(v * 100)}}%` : Math.round(v));
        g += `<line x1="${{pad.l}}" y1="${{y}}" x2="${{w-pad.r}}" y2="${{y}}" stroke="#edf1f4"/>
              <text x="${{pad.l-10}}" y="${{y+4}}" text-anchor="end" fill="#64717f" font-size="12">${{label}}</text>`;
      }}
      g += `<text x="${{w/2}}" y="${{h-10}}" text-anchor="middle" fill="#314253" font-size="13">${{xLabel}}</text>
            <text transform="translate(16 ${{h/2}}) rotate(-90)" text-anchor="middle" fill="#314253" font-size="13">${{yLabel}}</text>`;
      svg.insertAdjacentHTML('beforeend', g);
    }}

    function pointTooltip(evt, text) {{
      const tip = $('tooltip');
      tip.textContent = text;
      tip.style.left = `${{evt.clientX}}px`;
      tip.style.top = `${{evt.clientY}}px`;
      tip.classList.add('show');
    }}
    function hideTooltip() {{ $('tooltip').classList.remove('show'); }}

    function drawTradeoff(ranked) {{
      const svg = $('tradeoffChart');
      svg.innerHTML = '';
      const w = 760, h = 430, pad = {{l: 70, r: 28, t: 28, b: 58}};
      const xs = data.summary.map(d => d.nominal_bandwidth_hz);
      const ys = data.summary.map(d => d.useful_bitrate_bps_for_payload);
      const scale = chartScales(xs, ys, w, h, pad);
      axes(svg, scale, w, h, pad, '标称带宽 Hz', '有效速率 bps');
      ranked.forEach(d => {{
        const x = scale.x(d.nominal_bandwidth_hz);
        const y = scale.y(d.useful_bitrate_bps_for_payload);
        const r = d.scheme === selected ? 10 : 7;
        const el = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        el.setAttribute('cx', x);
        el.setAttribute('cy', y);
        el.setAttribute('r', r);
        el.setAttribute('fill', colorByScheme[d.scheme]);
        el.setAttribute('stroke', d.scheme === selected ? '#101820' : 'white');
        el.setAttribute('stroke-width', d.scheme === selected ? '3' : '2');
        el.addEventListener('mousemove', e => pointTooltip(e, `${{d.scheme}} · ${{Math.round(d.useful_bitrate_bps_for_payload)}} bps · ${{Math.round(d.nominal_bandwidth_hz)}} Hz · 成功率 ${{pct(d.snrSuccess)}}`));
        el.addEventListener('mouseleave', hideTooltip);
        el.addEventListener('click', () => {{ selected = d.scheme; render(); }});
        svg.appendChild(el);
        svg.insertAdjacentHTML('beforeend', `<text x="${{x + 12}}" y="${{y + 4}}" fill="#263442" font-size="12">${{d.scheme}}</text>`);
      }});
      renderLegend('tradeoffLegend');
    }}

    function drawLineChart(svgId, legendId, source, key, metric, xLabel, yLabel) {{
      const svg = $(svgId);
      svg.innerHTML = '';
      const w = 760, h = 430, pad = {{l: 70, r: 28, t: 28, b: 58}};
      const xs = source.map(d => d[key]);
      const ys = source.map(d => d[metric]);
      const scale = chartScales(xs, ys, w, h, pad);
      axes(svg, scale, w, h, pad, xLabel, yLabel, true);
      data.summary.forEach(d => {{
        const rows = rowsForScheme(source, key, d.scheme);
        const points = rows.map(p => `${{scale.x(p[key])}},${{scale.y(p[metric])}}`).join(' ');
        svg.insertAdjacentHTML('beforeend', `<polyline points="${{points}}" fill="none" stroke="${{colorByScheme[d.scheme]}}" stroke-width="${{d.scheme === selected ? 4 : 2.4}}" opacity="${{d.scheme === selected ? 1 : .74}}"/>`);
        rows.forEach(p => {{
          const c = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
          c.setAttribute('cx', scale.x(p[key]));
          c.setAttribute('cy', scale.y(p[metric]));
          c.setAttribute('r', d.scheme === selected ? '5' : '3.5');
          c.setAttribute('fill', colorByScheme[d.scheme]);
          c.addEventListener('mousemove', e => pointTooltip(e, `${{d.scheme}} · ${{key}}=${{p[key]}} · 成功率 ${{pct(p[metric])}}`));
          c.addEventListener('mouseleave', hideTooltip);
          c.addEventListener('click', () => {{ selected = d.scheme; render(); }});
          svg.appendChild(c);
        }});
      }});
      renderLegend(legendId);
    }}

    function renderLegend(id) {{
      $(id).innerHTML = data.summary.map(d => `
        <button data-scheme="${{d.scheme}}">
          <span class="dot" style="background:${{colorByScheme[d.scheme]}}"></span>${{d.scheme}}
        </button>
      `).join('');
      document.querySelectorAll(`#${{id}} button`).forEach(btn => {{
        btn.addEventListener('click', () => {{ selected = btn.dataset.scheme; render(); }});
      }});
    }}

    function drawXY(svgId, xs, ys, xLabel, yLabel, color, yRange = null) {{
      const svg = $(svgId);
      svg.innerHTML = '';
      const w = 760, h = 320, pad = {{l: 62, r: 22, t: 20, b: 48}};
      const scale = chartScales(xs, ys, w, h, pad);
      if (yRange) {{
        scale.ymin = yRange[0];
        scale.ymax = yRange[1];
      }}
      axes(
        svg,
        scale,
        w,
        h,
        pad,
        xLabel,
        yLabel,
        false,
        v => Math.round(v),
        v => yLabel === '幅度' ? Number(v).toFixed(1) : Math.round(v)
      );
      const points = xs.map((x, i) => `${{scale.x(x)}},${{scale.y(ys[i])}}`).join(' ');
      svg.insertAdjacentHTML('beforeend', `<polyline points="${{points}}" fill="none" stroke="${{color}}" stroke-width="2.2"/>`);
    }}

    function miniWaveSvg(scheme) {{
      const wf = data.waveforms[scheme];
      const xs = wf.time_ms;
      const ys = wf.amplitude;
      const w = 260, h = 110, pad = {{l: 6, r: 6, t: 8, b: 14}};
      const xmin = Math.min(...xs), xmax = Math.max(...xs);
      const ymin = -1.25, ymax = 1.25;
      const sx = v => pad.l + (v - xmin) / Math.max(xmax - xmin, 1) * (w - pad.l - pad.r);
      const sy = v => h - pad.b - (v - ymin) / (ymax - ymin) * (h - pad.t - pad.b);
      const zero = sy(0);
      const points = xs.map((x, i) => `${{sx(x).toFixed(1)}},${{sy(ys[i]).toFixed(1)}}`).join(' ');
      return `<svg class="mini-wave" viewBox="0 0 ${{w}} ${{h}}">
        <line x1="${{pad.l}}" y1="${{zero}}" x2="${{w-pad.r}}" y2="${{zero}}" stroke="#dbe1e7"/>
        <polyline points="${{points}}" fill="none" stroke="${{colorByScheme[scheme]}}" stroke-width="1.8"/>
      </svg>`;
    }}

    function renderWaveforms(ranked) {{
      const d = ranked.find(x => x.scheme === selected) || ranked[0];
      const wf = data.waveforms[d.scheme];
      $('waveSelectedName').textContent = d.scheme;
      $('waveSelectedReason').textContent = `${{d.modulation.toUpperCase()}} · ${{d.goertzel_bins}} 个检测频点`;
      drawXY('selectedTimeChart', wf.time_ms, wf.amplitude, '时间 ms', '幅度', colorByScheme[d.scheme], [-1.25, 1.25]);
      drawXY('selectedSpectrumChart', wf.freq_hz, wf.spectrum_db, '频率 Hz', '相对幅度 dB', colorByScheme[d.scheme], [-72, 2]);
      $('waveMeta').innerHTML = [
        `<span class="chip">码元 ${{fmt(wf.symbol_ms, ' ms', 0)}}</span>`,
        `<span class="chip">示例码元 ${{wf.symbols.join(' ')}}</span>`,
        `<span class="chip">48 字符时长 ${{fmt(d.message_duration_s, ' s', 2)}}</span>`,
        `<span class="chip">标称带宽 ${{fmt(d.nominal_bandwidth_hz, ' Hz', 0)}}</span>`
      ].join('');

      $('waveCards').innerHTML = data.summary.map(item => {{
        const rank = ranked.find(x => x.scheme === item.scheme) || item;
        return `<div class="wave-card ${{item.scheme === selected ? 'selected' : ''}}" data-scheme="${{item.scheme}}">
          <h4><span>${{item.scheme}}</span><span class="status ${{statusClass(rank.snrSuccess)}}">${{pct(rank.snrSuccess)}}</span></h4>
          ${{miniWaveSvg(item.scheme)}}
          <div class="wave-meta">
            <span>${{fmt(item.message_duration_s, ' s', 2)}}</span>
            <span>${{fmt(item.nominal_bandwidth_hz, ' Hz', 0)}}</span>
            <span>${{item.goertzel_bins}} bin</span>
          </div>
        </div>`;
      }}).join('');
      document.querySelectorAll('#waveCards .wave-card').forEach(card => {{
        card.addEventListener('click', () => {{
          selected = card.dataset.scheme;
          render();
        }});
      }});
    }}

    function renderDetail(ranked) {{
      const d = ranked.find(x => x.scheme === selected) || ranked[0];
      const tones = String(d.tones_hz || '').split(' ').filter(Boolean).join(' / ');
      $('detailPanel').innerHTML = `
        <div class="kv"><span>调制</span><strong>${{d.modulation.toUpperCase()}} · ${{d.codec}}</strong></div>
        <div class="kv"><span>频点</span><strong>${{tones}} Hz</strong></div>
        <div class="kv"><span>波特率</span><strong>${{fmt(d.baud, ' baud', 1)}}</strong></div>
        <div class="kv"><span>有效速率</span><strong>${{fmt(d.useful_bitrate_bps_for_payload, ' bps', 0)}}</strong></div>
        <div class="kv"><span>48 字符时长</span><strong>${{fmt(d.message_duration_s, ' s', 2)}}</strong></div>
        <div class="kv"><span>检测复杂度</span><strong>${{d.goertzel_bins}} 个 Goertzel bin</strong></div>
        <div class="kv"><span>当前风险</span><strong>SNR ${{pct(d.snrSuccess)}} · 干扰 ${{pct(d.jamSuccess)}} · 频偏 ${{pct(d.offSuccess)}}</strong></div>
      `;
      $('reportText').textContent = `本设计优先选择 ${{d.scheme}} 方案。该方案码元速率约为 ${{fmt(d.baud, ' baud', 1)}}，48 字符英文短消息的有效传输速率约为 ${{fmt(d.useful_bitrate_bps_for_payload, ' bps', 0)}}，整包发送时间约为 ${{fmt(d.message_duration_s, ' s', 2)}}。接收端只需检测 ${{d.goertzel_bins}} 个候选频率，适合在单片机上使用 Goertzel 算法实现。当前仿真条件下，整包成功率约为 ${{pct(d.snrSuccess)}}，可作为后续硬件实测调参的基准。`;
    }}

    function render() {{
      updateLabels();
      const ranked = enrichSchemes();
      renderAlgorithmButtons();
      renderMetrics(ranked);
      renderBars(ranked);
      renderTable(ranked);
      drawTradeoff(ranked);
      renderWaveforms(ranked);
      drawLineChart('snrSuccessChart', 'snrLegend', data.snr, 'snr_db', 'packet_success', 'SNR dB', '整包成功率');
      drawLineChart('jammerChart', 'jammerLegend', data.jammer, 'jammer_jsr_db', 'packet_success', 'JSR dB', '整包成功率');
      drawLineChart('offsetChart', 'offsetLegend', data.offset, 'tx_freq_offset_hz', 'packet_success', '频率偏差 Hz', '整包成功率');
      renderDetail(ranked);
    }}

    document.querySelectorAll('.tab').forEach(btn => {{
      btn.addEventListener('click', () => {{
        activeTab = btn.dataset.tab;
        document.querySelectorAll('.tab').forEach(b => b.setAttribute('aria-selected', String(b === btn)));
        document.querySelectorAll('.section').forEach(sec => sec.classList.toggle('active', sec.id === activeTab));
        render();
      }});
    }});
    ['snr', 'jsr', 'offset', 'wReliability', 'wSpeed', 'wSimplicity'].forEach(id => $(id).addEventListener('input', render));
    document.querySelectorAll('[data-preset]').forEach(btn => btn.addEventListener('click', () => applyPreset(btn.dataset.preset)));
    render();
  </script>
</body>
</html>"""


def write_dashboard(
    out_dir: Path,
    summary: pd.DataFrame,
    snr: pd.DataFrame,
    jammer: pd.DataFrame,
    offset: pd.DataFrame,
    waveforms: dict[str, dict[str, object]],
) -> None:
    payload = {
        "summary": summary.to_dict(orient="records"),
        "snr": snr.to_dict(orient="records"),
        "jammer": jammer.to_dict(orient="records"),
        "offset": offset.to_dict(orient="records"),
        "waveforms": waveforms,
        "thresholds": snr_threshold(snr, 0.95),
    }
    data_json = json.dumps(payload, ensure_ascii=False)
    (out_dir / "dashboard.html").write_text(dashboard_html(data_json), encoding="utf-8")


def plot_results(summary: pd.DataFrame, snr: pd.DataFrame, jammer: pd.DataFrame, offset: pd.DataFrame, out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)

    plt.figure(figsize=(9, 5))
    for scheme, part in snr.groupby("scheme"):
        part = part.sort_values("snr_db")
        plt.semilogy(part["snr_db"], np.maximum(part["ber"], 1e-5), marker="o", label=scheme)
    plt.xlabel("SNR (dB)")
    plt.ylabel("BER")
    plt.title("Bit error rate vs SNR")
    plt.grid(True, which="both", alpha=0.3)
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(out_dir / "ber_vs_snr.png", dpi=180)
    plt.close()

    plt.figure(figsize=(9, 5))
    for scheme, part in snr.groupby("scheme"):
        part = part.sort_values("snr_db")
        plt.plot(part["snr_db"], part["packet_success"], marker="o", label=scheme)
    plt.xlabel("SNR (dB)")
    plt.ylabel("48-char message success")
    plt.title("Packet success vs SNR")
    plt.ylim(-0.05, 1.05)
    plt.grid(True, alpha=0.3)
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(out_dir / "success_vs_snr.png", dpi=180)
    plt.close()

    plt.figure(figsize=(9, 5))
    for scheme, part in jammer.groupby("scheme"):
        part = part.sort_values("jammer_jsr_db")
        plt.plot(part["jammer_jsr_db"], part["packet_success"], marker="o", label=scheme)
    plt.xlabel("Narrowband jammer JSR (dB)")
    plt.ylabel("48-char message success")
    plt.title("Success under same-tone narrowband interference")
    plt.ylim(-0.05, 1.05)
    plt.grid(True, alpha=0.3)
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(out_dir / "interference_success.png", dpi=180)
    plt.close()

    plt.figure(figsize=(9, 5))
    for scheme, part in offset.groupby("scheme"):
        part = part.sort_values("tx_freq_offset_hz")
        plt.plot(part["tx_freq_offset_hz"], part["packet_success"], marker="o", label=scheme)
    plt.xlabel("TX/RX tone frequency offset (Hz)")
    plt.ylabel("48-char message success")
    plt.title("Frequency-offset tolerance")
    plt.ylim(-0.05, 1.05)
    plt.grid(True, alpha=0.3)
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(out_dir / "frequency_offset_success.png", dpi=180)
    plt.close()

    plt.figure(figsize=(8, 5))
    plt.scatter(summary["nominal_bandwidth_hz"], summary["useful_bitrate_bps_for_payload"], s=70)
    for _, row in summary.iterrows():
        plt.annotate(row["scheme"], (row["nominal_bandwidth_hz"], row["useful_bitrate_bps_for_payload"]), xytext=(5, 5), textcoords="offset points", fontsize=8)
    plt.xlabel("Nominal bandwidth (Hz)")
    plt.ylabel("Useful bitrate for payload (bps)")
    plt.title("Bandwidth-rate tradeoff")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_dir / "bandwidth_rate_tradeoff.png", dpi=180)
    plt.close()


def write_report(
    out_dir: Path,
    summary: pd.DataFrame,
    snr: pd.DataFrame,
    jammer: pd.DataFrame,
    offset: pd.DataFrame,
    payload_chars: int,
    trials: int,
) -> None:
    thresholds = snr_threshold(snr, 0.95)
    merged = summary.copy()
    merged["snr_for_95pct_packet_success_db"] = merged["scheme"].map(thresholds)

    top = merged.sort_values(
        by=["snr_for_95pct_packet_success_db", "message_duration_s"],
        na_position="last",
    )

    table_cols = [
        "scheme",
        "codec",
        "baud",
        "useful_bitrate_bps_for_payload",
        "message_duration_s",
        "nominal_bandwidth_hz",
        "spectral_efficiency_bps_per_hz",
        "goertzel_bins",
        "snr_for_95pct_packet_success_db",
    ]
    table = markdown_table(merged[table_cols].round(3))

    best_balanced = "4FSK"

    report = f"""# 声语信使算法选型仿真报告

## 仿真对象

- 任务约束：20 Hz-20 kHz 音频声波、1-48 字符短信息、0.5 m 以上通信距离、自然环境噪声不超过 55 dB。
- 本轮默认载荷：{payload_chars} 字符，按英文/符号场景估算为 {payload_chars * 8} bit。
- 每个测试点 Monte Carlo 次数：{trials}。
- 接收机模型：按码元窗口计算候选频率能量，等价于 MCU 上常见的 Goertzel/短窗 FFT 判决。

## 主要指标

{table}

## 初步结论

1. OOK 实现最简单、带宽最窄，但能量门限容易受环境噪声、扬声器音量和同频干扰影响，不建议作为最终方案。
2. 2FSK 抗噪声通常明显好于 OOK，但 1 bit/baud 导致 48 字符英文消息耗时较长。
3. 4FSK 是本任务的首选平衡点：实现复杂度仍低，只需 4 个频率检测 bin，在速度、带宽和鲁棒性之间比较均衡。
4. 4FSK + Hamming(7,4) 牺牲吞吐率换纠错能力，适合后期提高通信距离或在教室噪声偏大的环境中保底。
5. 8FSK 速度高，但占用频带更宽，频率响应不平坦、频偏和窄带干扰会更敏感，适合作为提高部分的候选，不建议直接作为第一版。
6. DTMF 的工程成熟度高、判决直观，适合数字/按键编码；若要传完整英文消息，需要 16 进制或字符表映射，码元较长时总时延不一定优于 4FSK。

## 建议方案

推荐以 `{best_balanced}` 作为算法选型主线。课程实物第一版可先实现 `4FSK`，频率可放在 1.4/1.7/2.0/2.3 kHz，码元宽度 20 ms，接收端用 Goertzel 检测最大能量频点。若实测距离或误码不达标，再启用 `4FSK_Hamming74`、CRC 与重发机制作为可靠增强。

## 后续应补充的硬件相关指标

- 实测扬声器-话筒频响曲线：不同频点声压/ADC 幅度会影响 MFSK 频率选择。
- 实测环境噪声谱：若 1-2 kHz 附近噪声强，应整体上移或避开噪声峰。
- AGC/幅度归一化策略：影响 OOK 和 DTMF 门限稳定性。
- 同步方式：前导码、起始符、码元定时恢复会影响真实误包率。
- 功耗：码元时长越长，扬声器持续发声时间越长，平均发送能耗越高。

## 输出文件

- `summary.csv`：带宽、波特率、有效速率、复杂度等静态指标。
- `snr_sweep.csv`：不同 SNR 下 BER/SER/整包成功率。
- `jammer_sweep.csv`：窄带同频干扰下成功率。
- `freq_offset_sweep.csv`：发接频率偏差下成功率。
- `*.png`：对应指标图。
"""
    (out_dir / "algorithm_selection_report.md").write_text(report, encoding="utf-8")


def parse_float_list(text: str) -> list[float]:
    return [float(x.strip()) for x in text.split(",") if x.strip()]


def main() -> None:
    parser = argparse.ArgumentParser(description="Sound messenger modulation selection simulator")
    parser.add_argument("--out", type=Path, default=Path("results"), help="output directory")
    parser.add_argument("--payload-chars", type=int, default=48)
    parser.add_argument("--trials", type=int, default=12)
    parser.add_argument("--seed", type=int, default=DEFAULT_SEED)
    parser.add_argument("--snr-values", type=str, default="-30,-27,-24,-21,-18,-15,-12,-9,-6,-3,0,3,6,9,12")
    parser.add_argument("--jsr-values", type=str, default="-24,-18,-12,-6,0,6")
    parser.add_argument("--offset-values", type=str, default="0,5,10,20,40,80")
    parser.add_argument("--fixed-snr", type=float, default=12.0)
    parser.add_argument("--offset-snr", type=float, default=18.0)
    args = parser.parse_args()

    out_dir = args.out
    out_dir.mkdir(parents=True, exist_ok=True)
    schemes = default_schemes()
    payload_bits = args.payload_chars * 8

    summary = summarize_schemes(schemes, payload_bits, FS, args.seed)
    snr = run_condition(
        schemes,
        payload_bits,
        args.trials,
        args.seed,
        "snr_sweep",
        parse_float_list(args.snr_values),
        "snr_db",
    )
    jammer = run_condition(
        schemes,
        payload_bits,
        args.trials,
        args.seed + 17,
        "jammer_sweep",
        parse_float_list(args.jsr_values),
        "jammer_jsr_db",
        snr_db=args.fixed_snr,
    )
    offset = run_condition(
        schemes,
        payload_bits,
        args.trials,
        args.seed + 31,
        "freq_offset_sweep",
        parse_float_list(args.offset_values),
        "tx_freq_offset_hz",
        snr_db=args.offset_snr,
    )

    waveforms = waveform_previews(schemes, FS)
    summary.to_csv(out_dir / "summary.csv", index=False, encoding="utf-8-sig")
    snr.to_csv(out_dir / "snr_sweep.csv", index=False, encoding="utf-8-sig")
    jammer.to_csv(out_dir / "jammer_sweep.csv", index=False, encoding="utf-8-sig")
    offset.to_csv(out_dir / "freq_offset_sweep.csv", index=False, encoding="utf-8-sig")

    config = {
        "fs": FS,
        "payload_chars": args.payload_chars,
        "payload_bits": payload_bits,
        "trials": args.trials,
        "seed": args.seed,
        "snr_values": parse_float_list(args.snr_values),
        "jsr_values": parse_float_list(args.jsr_values),
        "offset_values": parse_float_list(args.offset_values),
        "fixed_snr_for_jammer_sweep_db": args.fixed_snr,
        "fixed_snr_for_offset_sweep_db": args.offset_snr,
    }
    (out_dir / "run_config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")

    plot_results(summary, snr, jammer, offset, out_dir)
    write_dashboard(out_dir, summary, snr, jammer, offset, waveforms)
    write_report(out_dir, summary, snr, jammer, offset, args.payload_chars, args.trials)

    print(f"wrote results to {out_dir.resolve()}")


if __name__ == "__main__":
    main()
