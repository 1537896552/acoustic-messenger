# 声语信使算法选型仿真平台

这个平台用于比较声波短消息通信中的算法选型，默认围绕课程任务中的 1-48 字符短信息、20 Hz-20 kHz 声波、0.5 m 以上通信距离等要求设置。

## 打开方式

先运行：

```powershell
python .\sound_messenger_sim.py --out .\results
```

然后用浏览器打开：

```text
results\dashboard.html
```

`dashboard.html` 是纯静态页面，不需要启动服务器。

## 交互界面

- 左侧“算法按钮”：切换当前查看的 OOK、2FSK、4FSK、4FSK+Hamming、8FSK、DTMF。
- 左侧“一键场景”：快速切到安静教室、噪声偏大、强干扰、频偏较大、可靠优先、速度优先。
- 左侧滑块：调信噪比、窄带干扰强度、发接频率偏差，以及可靠性/速度/实现简单度的选型权重。
- “总览”页：显示推荐算法、当前成功率、有效速率、带宽、检测复杂度和方案排序。
- “波形”页：显示选中算法的时域波形、频谱，以及全部候选算法的小波形卡片。
- “信噪比”页：显示不同 SNR 下的整包成功率曲线。
- “抗干扰”页：显示窄带同频干扰和频率偏差下的成功率。
- “实现”页：给出当前选中方案的频点、码元时长、波特率、Goertzel 检测 bin 数和可写入报告的表述。

## 默认候选方案

- `OOK_1800`：单频开关键控，实现最简单，但门限抗扰动弱。
- `2FSK`：二进制频移键控，鲁棒性较好但速率低。
- `4FSK`：推荐第一版主线，速度、带宽、复杂度比较均衡。
- `4FSK_Hamming74`：在 4FSK 上增加 Hamming(7,4) 纠错，牺牲速率换可靠性。
- `8FSK`：速率高但频带更宽，检测点更多。
- `DTMF`：双音多频，工程成熟，适合按键/数字类编码。

## 输出文件

- `dashboard.html`：交互式算法选型工作台。
- `algorithm_selection_report.md`：自动生成的选型报告草稿。
- `summary.csv`：波特率、带宽、有效速率、复杂度等静态指标。
- `snr_sweep.csv`：不同 SNR 下的 BER/SER/整包成功率。
- `jammer_sweep.csv`：窄带同频干扰下的结果。
- `freq_offset_sweep.csv`：频率偏差下的结果。
- `*.png`：可直接放入设计报告的静态图。

## 重新扫参示例

```powershell
python .\sound_messenger_sim.py --out .\results_more --trials 40 --payload-chars 48
```

```powershell
python .\sound_messenger_sim.py --out .\results_low_snr --snr-values='-36,-33,-30,-27,-24,-21,-18,-15,-12,-9,-6'
```

如果后期拿到实际扬声器和驻极体话筒的频响，可以把 `default_schemes()` 里的频点改成避开噪声峰、又处在硬件响应较平坦的位置。
