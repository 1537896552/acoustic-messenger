# STM32 4FSK 音频通信硬件配置指南

## 概述

4FSK 音频通信利用 STM32 的 DAC/ADC 在音频频段(300Hz-3kHz)完成数据传输。
发送端将数字信号调制成 4FSK 音频通过 DAC 输出,接收端通过 ADC 采样后解调。

## 硬件连接

### 基本连接 (有线测试)

```
[发送端 STM32]                    [接收端 STM32]
    DAC(PA4) ----[耦合电容]---->   ADC(PA0)
    GND ----------------------->  GND
```

### 耦合电路 (必需)

DAC 输出 0-3.3V,带 1.65V 直流偏置。ADC 输入需要信号在 0-3.3V 范围内。

```
DAC(PA4) ----||----+---- ADC(PA0)
             10uF  |
                   R1 100k
                   |
                  GND

R1 提供 ADC 输入的直流偏置 (约 Vdda/2)。
电容隔直,防止 DAC 的直流偏置影响 ADC 工作点。
```

### 无线方案

将 DAC 输出连接到 FM 发射模块的音频输入,接收端用 FM 接收模块解调后
送入 ADC。推荐:
- 发射: 简易 FM 话筒模块 (如 MAX2606)
- 接收: FM 收音机模块 (如 RDA5807)

## STM32 外设配置

### CubeMX 设置

#### DAC (发送)
- Peripheral: DAC1, Channel 1 (PA4)
- Trigger: Timer 6 Trigger Out
- Mode: 12-bit right alignment
- DMA: Circular mode, Half-Word

#### ADC (接收)
- Peripheral: ADC1, Channel 0 (PA0)
- Trigger: Timer 2 Trigger Out
- Mode: 12-bit, Continuous Conversion
- DMA: Circular mode, Half-Word

#### TIM6 (DAC 触发)
- Prescaler: (APB1_TimerClock / sample_rate) - 1
- 例: 84MHz APB1, 8kHz sample → PSC = 84M/8000 - 1 = 10499
- AutoReload: 1 (每个时钟输出一个触发脉冲)

#### TIM2 (ADC 触发)
- 同 TIM6 配置

#### DMA 配置
- DAC DMA: Memory-to-Peripheral, Circular, Half-Word
- ADC DMA: Peripheral-to-Memory, Circular, Half-Word

## 性能参数

| 参数 | 典型值 | 说明 |
|------|--------|------|
| 采样率 | 8000 Hz | 可上调至 48kHz 提高码率 |
| 符号率 | 100 Baud | 4FSK 每符号2bit = 200bps |
| 载频 | 1100-1700 Hz | 在音频通带内 |
| 频偏 | 200 Hz | 抗噪能力与码率间的折中 |
| 误码率 | <1% @ SNR>10dB | 有线连接实测 |

## 提高通信速率

将采样率提升至 48000 Hz,符号率提升至 1200 Baud:
```
FSK_SAMPLE_RATE  = 48000
FSK_SYMBOL_RATE  = 1200   (4FSK: 2400 bps)
FSK_FIRST_FREQ   = 2000
FSK_FREQ_SHIFT   = 400
```

## 支持的开发板

理论上支持所有带 DAC+ADC 的 STM32 系列:
- STM32F4 Discovery (STM32F407VG) — 已测试
- STM32F401 Nucleo (STM32F401RE)
- STM32G431 Nucleo (STM32G431KB)
- STM32L476 Nucleo (STM32L476RG)
- STM32H743 Nucleo (STM32H743ZI)
