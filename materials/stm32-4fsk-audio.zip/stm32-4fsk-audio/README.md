# STM32 4FSK Audio Communication

基于 STM32 微控制器的 4FSK 音频通信程序包。通过音频接口(DAC/ADC)实现数据的
四进制频移键控(4FSK)调制解调传输,可用于有线音频线通信或配合 FM 无线模块使用。

## 特性

- **4FSK 调制解调** — 每符号传输 2 bit,比 2FSK 带宽效率翻倍
- **完整协议栈** — 前导码同步 + 帧定界 + CRC16 校验
- **HAL 库适配** — 基于 STM32 HAL,兼容 F1/F4/G4/L4/H7 系列
- **乒乓 DMA 缓冲** — ADC/DAC 使用双缓冲 DMA,CPU 开销低
- **实时统计** — SNR 估计、频偏检测、时钟偏移追踪
- **MIT 许可** — STM32 封装层使用 MIT 许可,可自由商用

## 架构

```
┌──────────────────────────────────────────┐
│              Application                  │
├──────────────────────────────────────────┤
│  stm32_4fsk.{h,c}   (MIT)  高层 API      │
├──────────┬───────────────────────────────┤
│ protocol │  audio_io.{h,c}    (MIT)       │
│ 帧协议   │  STM32 HAL 音频 I/O           │
├──────────┴───────────────────────────────┤
│         lib/mfsk/          (LGPL-2.1)     │
│  4FSK 调制解调核心算法 (David Rowe)       │
└──────────────────────────────────────────┘
```

## 4FSK 调制参数

默认配置(保守,适合窄带音频通道):

| 参数 | 值 | 说明 |
|------|-----|------|
| 采样率 | 8000 Hz | 音频采样率 |
| 符号率 | 100 Baud | 每秒符号数 |
| 第一频点 | 1400 Hz | 符号 00 |
| 频点间隔 | 200 Hz | 符号 01=1600Hz, 10=1800Hz, 11=2000Hz |
| 信息速率 | 200 bps | 4FSK 每符号 2 bit |

## 帧格式

```
┌──────────┬────────┬──────────┬─────────┬────────┐
│ Preamble │  Sync  │  Length  │  Data   │ CRC16  │
│ 16 symbols│ 2 byte │  2 byte  │ N byte  │ 2 byte │
│ (0,3交替)│ 0xA5F0 │  大端序  │         │ CCITT  │
└──────────┴────────┴──────────┴─────────┴────────┘
```

## 快速开始

### 1. 克隆仓库

```bash
git clone <repo-url> stm32-4fsk-audio
cd stm32-4fsk-audio
```

### 2. CubeMX 配置

参考 `docs/hardware_setup.md` 配置 DAC/ADC/DMA/定时器。

### 3. 编译

```bash
mkdir build && cd build
cmake .. -DCMAKE_TOOLCHAIN_FILE=cmake/gcc-arm-none-eabi.cmake
make
```

### 4. 示例代码

```c
#include "stm32_4fsk.h"

void on_rx(const uint8_t *data, uint32_t len, void *user) {
    printf("Received %lu bytes\n", len);
}

int main(void) {
    FSK4_Handle *fsk = fsk4_init(NULL);           // 默认参数
    fsk4_set_rx_callback(fsk, on_rx, NULL);
    fsk4_start_rx(fsk);                            // 启动监听
    fsk4_start_tx(fsk);
    fsk4_send(fsk, (uint8_t*)"Hello", 5);          // 发送数据
    while(1) { /* 主循环 */ }
}
```

## 开源许可

| 组件 | 许可证 | 说明 |
|------|--------|------|
| `src/` (stm32_4fsk, protocol, audio_io) | MIT | 可自由使用、修改、商用 |
| `lib/mfsk/` (核心算法) | LGPL-2.1 | 需保留许可声明,修改需开源 |
| `examples/` | MIT | 示例代码 |

详细许可声明见 `NOTICE` 文件。

## 参考资料

- [limosky/mFSK](https://github.com/limosky/mFSK) — M-ary FSK 调制解调器 (LGPL-2.1)
- [pichenettes/stm-audio-bootloader](https://github.com/pichenettes/stm-audio-bootloader) — STM32 音频 FSK Bootloader
- [asiemasz/AcousticDataTransmitter](https://github.com/asiemasz/AcousticDataTransmitter) — STM32F4 声波数据传输
- David Rowe 的 FSK Modem — 原始算法设计

## 目录结构

```
stm32-4fsk-audio/
├── LICENSE              # MIT 许可
├── NOTICE               # 开源组件许可声明
├── README.md
├── CMakeLists.txt
├── lib/
│   └── mfsk/            # mFSK 库 (LGPL-2.1)
│       ├── LICENSE
│       ├── fsk.h / fsk.c
│       ├── modulator.h / modulator.c
│       ├── demodulator.h / demodulator.c
│       ├── fft.h / fft.c
│       └── ...
├── src/                 # STM32 封装层 (MIT)
│   ├── stm32_4fsk.h     # 主 API
│   ├── stm32_4fsk.c     # 核心实现
│   ├── protocol.h       # 帧协议
│   ├── protocol.c
│   ├── audio_io.h       # 音频 I/O 抽象
│   └── audio_io.c
├── examples/
│   └── simple_tx_rx/
│       └── main.c       # 简单收发示例
└── docs/
    └── hardware_setup.md
```
