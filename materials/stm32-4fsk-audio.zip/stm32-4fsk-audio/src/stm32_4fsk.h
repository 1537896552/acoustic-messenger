/**
 * stm32_4fsk.h - STM32 4FSK Audio Communication API
 *
 * MIT License
 * Copyright (c) 2024
 *
 * 基于 mFSK 库 (LGPL-2.1) 的 STM32 音频 4FSK 通信封装层。
 * 通过音频接口（ADC/DAC）实现数据的 4FSK 调制解调传输。
 *
 * 依赖:
 *   - STM32 HAL 库
 *   - lib/mfsk (LGPL-2.1)
 *   - ARM CMSIS-DSP (可选,用于FFT加速)
 */

#ifndef STM32_4FSK_H
#define STM32_4FSK_H

#include <stdint.h>
#include <stdbool.h>
#include <complex.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ================================================================
 * 配置宏 (可在 stm32_4fsk_config.h 中覆盖)
 * ================================================================ */

#ifndef FSK_SAMPLE_RATE
#define FSK_SAMPLE_RATE      8000    /* 音频采样率 (Hz) */
#endif

#ifndef FSK_SYMBOL_RATE
#define FSK_SYMBOL_RATE      100     /* 符号速率 (Baud) */
#endif

#ifndef FSK_FIRST_FREQ
#define FSK_FIRST_FREQ       1400    /* 第一个频点 (Hz) — 符号00 */
#endif

#ifndef FSK_FREQ_SHIFT
#define FSK_FREQ_SHIFT       200     /* 频点间隔 (Hz) */
#endif

#ifndef FSK_DAC_BUFFER_SIZE
#define FSK_DAC_BUFFER_SIZE  256     /* DAC DMA缓冲区大小 */
#endif

#ifndef FSK_ADC_BUFFER_SIZE
#define FSK_ADC_BUFFER_SIZE  1024    /* ADC DMA缓冲区大小 */
#endif

#ifndef FSK_SYNC_PREAMBLE_LEN
#define FSK_SYNC_PREAMBLE_LEN 16     /* 同步前导码长度 (符号数) */
#endif

#ifndef FSK_MAX_PAYLOAD_SIZE
#define FSK_MAX_PAYLOAD_SIZE  48     /* 最大负载字节数 */
#endif

#ifndef FSK_SQUELCH_THRESHOLD
#define FSK_SQUELCH_THRESHOLD  2000  /* 静噪门限: 交流峰值(int16), <此值视为噪声 */
                                     /* 2000 ≈ 0.1V (0.1/3.3×4096×16) */
#endif

#ifndef FSK_PREAMBLE_MATCH_MIN
#define FSK_PREAMBLE_MATCH_MIN 12    /* 前导码最低匹配数 (16个中至少匹配此数) */
#endif

/* ================================================================
 * 类型定义
 * ================================================================ */

/** 4FSK 调制解调器句柄 */
typedef struct FSK4_Handle FSK4_Handle;

/** 工作模式 */
typedef enum {
    FSK4_MODE_IDLE = 0,
    FSK4_MODE_TX   = 1,
    FSK4_MODE_RX   = 2,
    FSK4_MODE_LOOPBACK = 3
} FSK4_Mode;

/** 调制参数 */
typedef struct {
    uint32_t sample_rate;       /* 采样率 (Hz), 默认 8000 */
    uint32_t symbol_rate;       /* 符号率 (Baud), 默认 100 */
    uint32_t first_freq;        /* 第一个频点 (Hz), 默认 1400 */
    uint32_t freq_shift;        /* 频点间隔 (Hz), 默认 200 */
    uint16_t squelch_threshold; /* 静噪门限(int16交流峰值),低于此值跳过解调,默认2000≈0.1V */
    uint8_t  preamble_match_min;/* 前导码最低匹配符号数, 默认 12 (共16) */
} FSK4_Config;

/** 发送/接收统计 */
typedef struct {
    uint32_t bytes_sent;
    uint32_t bytes_received;
    uint32_t packets_sent;
    uint32_t packets_received;
    uint32_t crc_errors;
    uint32_t sync_timeouts;
    float    snr_estimate;      /* 估计信噪比 (dB) */
    float    freq_offset;       /* 估计频偏 (Hz) */
    float    clock_offset_ppm;  /* 时钟偏移 (ppm) */
} FSK4_Stats;

/** 接收回调函数类型 */
typedef void (*FSK4_RxCallback)(uint8_t src_addr, const uint8_t *data,
                                 uint32_t len, void *user_data);

/** 发送完成回调 */
typedef void (*FSK4_TxDoneCallback)(void *user_data);

/** 错误回调 */
typedef void (*FSK4_ErrorCallback)(int error_code, void *user_data);

/* ================================================================
 * API 函数
 * ================================================================ */

/**
 * 初始化 4FSK 调制解调器
 * @param config  调制参数 (NULL 则使用默认值)
 * @param my_addr 本机地址 (0-15)
 * @return 句柄, NULL 表示失败
 */
FSK4_Handle* fsk4_init(const FSK4_Config *config, uint8_t my_addr);

/**
 * 反初始化,释放资源
 */
void fsk4_deinit(FSK4_Handle *h);

/**
 * 设置回调函数
 */
void fsk4_set_rx_callback(FSK4_Handle *h, FSK4_RxCallback cb, void *user_data);
void fsk4_set_tx_done_callback(FSK4_Handle *h, FSK4_TxDoneCallback cb, void *user_data);
void fsk4_set_error_callback(FSK4_Handle *h, FSK4_ErrorCallback cb, void *user_data);

/**
 * 启动/停止指定模式
 * 硬件初始化(ADC/DAC/DMA)在这些函数内部完成
 */
int  fsk4_start_tx(FSK4_Handle *h);
int  fsk4_start_rx(FSK4_Handle *h);
int  fsk4_stop(FSK4_Handle *h);

/**
 * 发送数据 (非阻塞)
 * 数据被复制到内部缓冲区,通过DMA异步发送
 * @param dst_addr 目标地址 (0-15)
 * @param data     数据指针
 * @param len      数据长度 (最大 FSK_MAX_PAYLOAD_SIZE, 即48)
 * @return 0 成功, -1 忙, -2 长度超限
 */
int  fsk4_send(FSK4_Handle *h, uint8_t dst_addr, const uint8_t *data, uint32_t len);

/**
 * 获取统计信息
 */
void fsk4_get_stats(FSK4_Handle *h, FSK4_Stats *stats);

/**
 * 重置统计信息
 */
void fsk4_reset_stats(FSK4_Handle *h);

/**
 * 获取当前模式
 */
FSK4_Mode fsk4_get_mode(FSK4_Handle *h);

/**
 * 检查是否正在发送
 */
bool fsk4_is_busy(FSK4_Handle *h);

/**
 * 设置静噪门限
 * @param threshold 交流峰值门限 (int16), 信号幅值低于此值视为噪声
 *                  2000 ≈ 0.1V, 5000 ≈ 0.25V
 *                  设为 0 则关闭静噪(始终接收)
 */
void fsk4_set_squelch(FSK4_Handle *h, uint16_t threshold);

#ifdef __cplusplus
}
#endif

#endif /* STM32_4FSK_H */
