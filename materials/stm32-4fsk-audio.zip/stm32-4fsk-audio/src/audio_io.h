/**
 * audio_io.h - STM32 音频 I/O 硬件抽象层
 *
 * MIT License
 * Copyright (c) 2024
 *
 * 使用 STM32 HAL 库的 DAC + DMA 发送和 ADC + DMA 接收。
 * 支持 STM32F1/F4/G4/L4/H7 系列。
 *
 * 硬件连接要求:
 *   DAC输出 -> 音频输出 (PA4 或 PA5, 取决于芯片)
 *   ADC输入 -> 音频输入 (如 PA0/PA1)
 *   需外部直流偏置电路使ADC输入在0-Vdda范围内
 */

#ifndef FSK4_AUDIO_IO_H
#define FSK4_AUDIO_IO_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ---- 平台检测 ---- */
#if defined(STM32F4) || defined(STM32F407xx) || defined(STM32F429xx)
  #define FSK4_HW_SERIES "STM32F4"
#elif defined(STM32F1) || defined(STM32F103xB)
  #define FSK4_HW_SERIES "STM32F1"
#elif defined(STM32G4) || defined(STM32G431xx) || defined(STM32G474xx)
  #define FSK4_HW_SERIES "STM32G4"
#elif defined(STM32L4) || defined(STM32L476xx)
  #define FSK4_HW_SERIES "STM32L4"
#elif defined(STM32H7) || defined(STM32H743xx)
  #define FSK4_HW_SERIES "STM32H7"
#else
  #define FSK4_HW_SERIES "STM32_UNKNOWN"
#endif

/* ---- DAC 配置 ---- */
#ifndef AUDIO_DAC
  #define AUDIO_DAC            DAC1
#endif
#ifndef AUDIO_DAC_CHANNEL
  #define AUDIO_DAC_CHANNEL    DAC_CHANNEL_1   /* PA4 */
#endif
#ifndef AUDIO_DAC_TIMER
  #define AUDIO_DAC_TIMER      TIM6
#endif
#ifndef AUDIO_DAC_DMA
  #define AUDIO_DAC_DMA        DMA1_Stream5    /* STM32F4 DMA2 */
#endif
#ifndef AUDIO_DAC_DMA_CHANNEL
  #define AUDIO_DAC_DMA_CHANNEL DMA_CHANNEL_7
#endif

/* ---- ADC 配置 ---- */
#ifndef AUDIO_ADC
  #define AUDIO_ADC            ADC1
#endif
#ifndef AUDIO_ADC_CHANNEL
  #define AUDIO_ADC_CHANNEL    ADC_CHANNEL_0   /* PA0 */
#endif
#ifndef AUDIO_ADC_TIMER
  #define AUDIO_ADC_TIMER      TIM2
#endif
#ifndef AUDIO_ADC_DMA
  #define AUDIO_ADC_DMA        DMA1_Stream0
#endif
#ifndef AUDIO_ADC_DMA_CHANNEL
  #define AUDIO_ADC_DMA_CHANNEL DMA_CHANNEL_0
#endif

/* ---- 音频 I/O 句柄 ---- */
typedef struct AudioIO_Handle AudioIO_Handle;

/** 音频缓冲区回调: 当新数据到达或发送缓冲区为空时调用 */
typedef void (*AudioIO_TxHalfCpltCallback)(void *user_data);
typedef void (*AudioIO_TxCpltCallback)(void *user_data);
typedef void (*AudioIO_RxHalfCpltCallback)(void *user_data);
typedef void (*AudioIO_RxCpltCallback)(void *user_data);

#define AUDIO_ADC_BUF_SIZE  1024
#define AUDIO_DAC_BUF_SIZE  256

struct AudioIO_Handle {
    /* 硬件句柄 */
    DAC_HandleTypeDef  *hdac;
    ADC_HandleTypeDef  *hadc;
    TIM_HandleTypeDef  *htim_dac;
    TIM_HandleTypeDef  *htim_adc;
    DMA_HandleTypeDef  *hdma_dac;
    DMA_HandleTypeDef  *hdma_adc;

    /* 双缓冲区 (乒乓缓冲) */
    uint16_t adc_buf[2][AUDIO_ADC_BUF_SIZE];
    uint16_t dac_buf[2][AUDIO_DAC_BUF_SIZE];
    uint8_t  adc_active_buf;     /* 当前ADC正在填充的缓冲区 */
    uint8_t  dac_active_buf;     /* 当前DAC正在发送的缓冲区 */

    /* 采样率 */
    uint32_t sample_rate;

    /* 回调 */
    AudioIO_TxHalfCpltCallback tx_half_cb;
    AudioIO_TxCpltCallback     tx_full_cb;
    AudioIO_RxHalfCpltCallback rx_half_cb;
    AudioIO_RxCpltCallback     rx_full_cb;
    void                       *user_data;

    /* 状态 */
    bool tx_running;
    bool rx_running;
};

/**
 * 初始化音频 I/O
 * @param h          句柄
 * @param sample_rate 采样率 (Hz)
 * @return 0 成功, -1 失败
 */
int  audio_io_init(AudioIO_Handle *h, uint32_t sample_rate);

/**
 * 反初始化
 */
void audio_io_deinit(AudioIO_Handle *h);

/**
 * 启动 DAC 发送
 */
int  audio_io_start_tx(AudioIO_Handle *h);

/**
 * 启动 ADC 接收
 */
int  audio_io_start_rx(AudioIO_Handle *h);

/**
 * 停止
 */
void audio_io_stop_tx(AudioIO_Handle *h);
void audio_io_stop_rx(AudioIO_Handle *h);

/**
 * 将调制后的样本写入 DAC 发送缓冲区
 * @param samples   int16_t 样本数组
 * @param count     样本数
 * @return 实际写入数
 */
int  audio_io_write_tx_buffer(AudioIO_Handle *h, const int16_t *samples, int count);

/**
 * 从 ADC 接收缓冲区读取样本
 * @param samples   输出缓冲区
 * @param count     请求样本数
 * @return 实际读取数
 */
int  audio_io_read_rx_buffer(AudioIO_Handle *h, int16_t *samples, int count);

/**
 * 检查发送缓冲区是否准备就绪 (可以写入新数据)
 */
bool audio_io_tx_ready(AudioIO_Handle *h);

/**
 * 检查接收缓冲区是否有足够数据
 */
int  audio_io_rx_available(AudioIO_Handle *h);

#ifdef __cplusplus
}
#endif

#endif /* FSK4_AUDIO_IO_H */
