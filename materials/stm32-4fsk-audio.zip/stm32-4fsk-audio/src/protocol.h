/**
 * protocol.h - 4FSK 音频通信协议层
 *
 * MIT License. Copyright (c) 2024
 *
 * 帧格式:
 * ┌──────────┬──────┬──────────┬────────┬───────┬──────┐
 * │ Preamble │ Sync │ Address  │ Length │ Data  │Cksum │
 * │ N symb   │2 byte│  1 byte  │ 1 byte │N byte │1 byte│
 * └──────────┴──────┴──────────┴────────┴───────┴──────┘
 *
 * Preamble: 交替发送 0x0/0x3 (最低频/最高频), 用于AFC+AGC
 * Sync:     同步字 0xA5 0xF0
 * Address:  高4位=地址, 低4位=地址按位取反 (用于检错)
 * Length:   数据长度 (1-48 字节)
 * Data:     负载数据
 * Cksum:    8位校验和 (Address+Length+Data 各字节累加取低8位)
 */

#ifndef FSK4_PROTOCOL_H
#define FSK4_PROTOCOL_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

#define PROTO_SYNC_WORD      0xA5F0
#define PROTO_PREAMBLE_SYMS  16
#define PROTO_MAX_PAYLOAD    48
#define PROTO_ADDR_MASK      0xF0
#define PROTO_ADDR_INV_MASK  0x0F

/* 帧开销: Sync(2) + Address(1) + Length(1) + Cksum(1) = 5 bytes */
#define PROTO_OVERHEAD        5
#define PROTO_MAX_FRAME_SYMS  (PROTO_PREAMBLE_SYMS + 2 + 1 + 1 + PROTO_MAX_PAYLOAD + 1)

/** 协议层状态 */
typedef enum {
    PROTO_STATE_IDLE = 0,
    PROTO_STATE_PREAMBLE,
    PROTO_STATE_SYNC,
    PROTO_STATE_ADDRESS,
    PROTO_STATE_LENGTH,
    PROTO_STATE_DATA,
    PROTO_STATE_CHECKSUM,
    PROTO_STATE_DONE
} ProtoState;

/** 协议层帧组装/解析上下文 */
typedef struct {
    ProtoState state;
    uint8_t    rx_buf[PROTO_MAX_PAYLOAD + PROTO_OVERHEAD]; /* 接收缓冲区 */
    uint32_t   rx_pos;
    uint32_t   rx_total_len;
    uint32_t   bit_index;
    uint8_t    current_byte;
    uint8_t    bits_in_byte;
    uint8_t    expected_addr;    /* 本机地址 (仅匹配此地址的帧被接收) */
    uint8_t    preamble_match_min; /* 前导码最低匹配数 */
    uint8_t    preamble_ring[16];  /* 前导码滑动窗口 */
    uint8_t    preamble_ring_idx;  /* 环形缓冲区写入位置 */
    uint8_t    preamble_matches;   /* 当前窗口中匹配的符号数 */
} ProtoContext;

/**
 * 初始化协议上下文
 * @param addr     本机地址 (0-15), 0xFF 表示接收所有地址
 * @param match_min 前导码最低匹配符号数 (16个中至少匹配此数)
 */
void proto_init(ProtoContext *ctx, uint8_t addr, uint8_t match_min);

/**
 * 组装发送帧
 * @param ctx      协议上下文
 * @param dst_addr 目标地址 (0-15)
 * @param data     负载数据
 * @param len      负载长度 (最大48)
 * @param out      输出缓冲区 (每个字节1个4FSK符号)
 * @return 帧总符号数, 0 表示失败
 */
uint32_t proto_build_frame(ProtoContext *ctx, uint8_t dst_addr,
                           const uint8_t *data, uint32_t len,
                           uint8_t *out);

/** 计算给定负载对应的帧总符号数 */
uint32_t proto_get_frame_size(uint32_t payload_len);

/**
 * 逐个符号喂入协议状态机
 * @param ctx  协议上下文
 * @param sym  解调符号 (0-3, 低2位有效)
 * @param addr 输出: 接收到的源地址 (0-15)
 * @param out  输出: 解码后的负载数据
 * @param len  输出: 负载长度
 * @return true 表示成功收到一个完整帧
 */
bool proto_feed_symbol(ProtoContext *ctx, uint8_t sym,
                       uint8_t *addr, uint8_t *out, uint32_t *len);

void proto_reset(ProtoContext *ctx);

/** 8位累加校验和 */
uint8_t proto_checksum(const uint8_t *data, uint32_t len);

#ifdef __cplusplus
}
#endif

#endif /* FSK4_PROTOCOL_H */
