/**
 * audio_io.c - STM32 音频 I/O 硬件抽象层实现
 *
 * MIT License. Copyright (c) 2024
 *
 * 使用 STM32 HAL 的 DAC+DMA 发送 / ADC+DMA 接收。
 * 用户需根据具体 STM32 型号配置 CubeMX 生成硬件初始化代码,
 * 然后将生成的 HAL 句柄传入 AudioIO_Handle。
 *
 * CubeMX 配置要点:
 *   DAC:  TIM6 触发, DMA 循环模式, 12-bit 右对齐
 *   ADC:  TIM2 触发, DMA 循环模式, 12-bit
 *   定时器频率 = sample_rate (如 8kHz)
 */

#include "audio_io.h"
#include <string.h>

/* ---- 硬件初始化 (平台相关,需根据实际型号调整) ---- */

int audio_io_init(AudioIO_Handle *h, uint32_t sample_rate) {
    memset(h, 0, sizeof(*h));
    h->sample_rate = sample_rate;
    /* 硬件初始化应由 CubeMX 生成的代码在外部完成,
     * 此处仅保存引用。用户需在执行 fsk4_init() 之前:
     *   1. MX_DAC_Init()
     *   2. MX_ADC_Init()
     *   3. MX_TIM6_Init()  / MX_TIM2_Init()
     *   4. MX_DMA_Init()
     * 并将句柄赋给 h->hdac, h->hadc, h->htim_dac 等字段。
     */
    return 0;
}

void audio_io_deinit(AudioIO_Handle *h) {
    (void)h;
}

/* ---- DAC 发送 ---- */

int audio_io_start_tx(AudioIO_Handle *h) {
    if (!h->hdac || !h->htim_dac || !h->hdma_dac) return -1;

    /* 初始填充两个半缓冲区 */
    memset(h->dac_buf[0], 2048, sizeof(h->dac_buf[0])); /* 中点值(静音) */
    memset(h->dac_buf[1], 2048, sizeof(h->dac_buf[1]));

    HAL_DAC_Start_DMA(h->hdac, AUDIO_DAC_CHANNEL,
                      (uint32_t *)h->dac_buf[0],
                      AUDIO_DAC_BUF_SIZE * 2,
                      DAC_ALIGN_12B_R);
    HAL_TIM_Base_Start(h->htim_dac);
    h->tx_running = true;
    return 0;
}

void audio_io_stop_tx(AudioIO_Handle *h) {
    if (h->tx_running) {
        HAL_DAC_Stop_DMA(h->hdac, AUDIO_DAC_CHANNEL);
        HAL_TIM_Base_Stop(h->htim_dac);
        h->tx_running = false;
    }
}

int audio_io_write_tx_buffer(AudioIO_Handle *h, const int16_t *samples,
                             int count) {
    if (count > AUDIO_DAC_BUF_SIZE) count = AUDIO_DAC_BUF_SIZE;

    /* 将 int16_t [-32768,32767] 转换为 DAC 12-bit [0,4095] */
    int buf_idx = h->dac_active_buf;
    for (int i = 0; i < count; i++) {
        /* 直流偏置到 1.65V (DAC中点 2048) */
        int32_t val = 2048 + (samples[i] * 2047 / 32768);
        if (val < 0) val = 0;
        if (val > 4095) val = 4095;
        h->dac_buf[buf_idx][i] = (uint16_t)val;
    }

    /* 填充剩余部分为静音 */
    for (int i = count; i < AUDIO_DAC_BUF_SIZE; i++) {
        h->dac_buf[buf_idx][i] = 2048;
    }

    return count;
}

bool audio_io_tx_ready(AudioIO_Handle *h) {
    return h->tx_running;
}

/* ---- ADC 接收 ---- */

int audio_io_start_rx(AudioIO_Handle *h) {
    if (!h->hadc || !h->htim_adc || !h->hdma_adc) return -1;

    HAL_ADC_Start_DMA(h->hadc,
                      (uint32_t *)h->adc_buf[0],
                      AUDIO_ADC_BUF_SIZE * 2);
    HAL_TIM_Base_Start(h->htim_adc);
    h->rx_running = true;
    return 0;
}

void audio_io_stop_rx(AudioIO_Handle *h) {
    if (h->rx_running) {
        HAL_ADC_Stop_DMA(h->hadc);
        HAL_TIM_Base_Stop(h->htim_adc);
        h->rx_running = false;
    }
}

int audio_io_read_rx_buffer(AudioIO_Handle *h, int16_t *samples, int count) {
    if (count > AUDIO_ADC_BUF_SIZE) count = AUDIO_ADC_BUF_SIZE;

    int buf_idx = h->adc_active_buf;
    for (int i = 0; i < count; i++) {
        /* ADC 12-bit [0,4095] -> int16_t [-32768,32767] */
        samples[i] = (int16_t)(((int32_t)h->adc_buf[buf_idx][i] - 2048) * 16);
    }
    return count;
}

int audio_io_rx_available(AudioIO_Handle *h) {
    return h->rx_running ? AUDIO_ADC_BUF_SIZE : 0;
}

/* ================================================================
 * HAL 回调 (用户需在 stm32f4xx_it.c 或类似位置调用)
 * ================================================================ */

void HAL_DAC_ConvHalfCpltCallbackCh1(DAC_HandleTypeDef *hdac) {
    /* 用户需实现: 从全局 AudioIO_Handle 中取指针,
     * 切换 dac_active_buf, 调用 tx_half_cb()
     */
}

void HAL_DAC_ConvCpltCallbackCh1(DAC_HandleTypeDef *hdac) {
    /* 同上,调用 tx_full_cb() */
}

void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef *hadc) {
    /* 切换 adc_active_buf, 调用 rx_half_cb() */
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc) {
    /* 调用 rx_full_cb() */
}
