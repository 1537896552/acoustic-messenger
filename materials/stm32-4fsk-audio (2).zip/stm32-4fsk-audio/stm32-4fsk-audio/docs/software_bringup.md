# Software bring-up notes

这份记录用于在硬件完全调通之前，先把 4FSK 软件链路跑通。

## 当前已修正的问题

### 1. 协议组帧输出类型错误

原来的 `proto_build_frame()` 把同步字、地址、长度、数据直接按字节写入 `tx_frame`，但发送端 `fill_tx_buffer()` 把 `tx_frame` 的每个元素当作 0-3 的 4FSK 符号发送。

结果是：

- `0xA5`、`0xF0` 等字节只会保留最低 2 bit；
- 接收端 `proto_feed_symbol()` 等不到正确同步字；
- 软件链路无法解出完整帧。

现在已经改成：

- 前导码仍为 0/3 交替符号；
- Sync、Address、Length、Data、Checksum 每个字节拆成 4 个 2-bit 符号；
- 接收端按同样的 MSB-first 顺序把 4 个符号还原成 1 个字节。

最大帧符号数也从错误的字节数量改为：

```c
PROTO_PREAMBLE_SYMS + ((PROTO_OVERHEAD + PROTO_MAX_PAYLOAD) * 4)
```

48 字节最大负载时为 `16 + 53*4 = 228` 个 4FSK 符号。

### 2. 示例代码直接访问不透明句柄

`FSK4_Handle` 在 `stm32_4fsk.h` 中是不透明类型，示例代码原来直接访问：

```c
fsk4->audio.hdac = &hdac;
```

这会导致编译时报 incomplete type。现在新增了公开 API：

```c
int fsk4_set_audio_handles(FSK4_Handle *h,
                           void *hdac, void *hadc,
                           void *htim_dac, void *htim_adc,
                           void *hdma_dac, void *hdma_adc);
```

示例代码改为：

```c
fsk4_set_audio_handles(fsk4,
                       &hdac, &hadc,
                       &htim6, &htim2,
                       &hdma_dac, &hdma_adc);
```

### 3. 示例程序 TX/RX 状态冲突

当前库的状态机不支持在同一个句柄中先 `fsk4_start_rx()` 再 `fsk4_start_tx()`。原示例先启动接收，再启动发送，发送端实际会启动失败。

现在示例改为分角色：

```c
#define DEMO_ROLE_TX  1
```

- 发送板设为 `1`；
- 接收板设为 `0`；
- 先用半双工/单向方式跑通。

## PC 端软件回环测试

新增了无需硬件的测试脚本：

```text
tools/host_loopback_sim.py
```

它验证完整软件链路：

```text
payload -> protocol symbols -> 4FSK waveform -> Goertzel demod
        -> protocol parser -> recovered payload
```

默认参数：

- 采样率：8000 Hz
- 符号率：100 baud
- 4FSK 频点：1500 / 1650 / 1800 / 1950 Hz
- 最大负载：48 字节

运行：

```powershell
python tools\host_loopback_sim.py
```

期望输出：

```text
RX payload     : b'Hello STM32 4FSK!'
RX             : OK
```

带噪声/频偏测试：

```powershell
python tools\host_loopback_sim.py --snr-db 0 --freq-offset-hz 5
```

脚本还会生成发送波形：

```text
build_host\tx_4fsk.wav
```

这个 wav 可以后续用电脑声卡、手机或示波器软件播放/观察。

## 仍需重点处理的问题

### 1. `process_rx_data()` 目前不适合直接使用 mFSK 解调器

当前 `process_rx_data()` 每 `Ts` 个采样调用一次：

```c
fsk_demod(h->fsk, h->rx_bits, h->rx_complex);
```

但 `fsk_create_hbr()` 默认 `Nsym = 48`，也就是说解调器一次期望处理 `48` 个符号，即：

```text
N = Ts * 48
```

当前只喂 1 个符号长度，存在解调错误或越界风险。

建议后续二选一：

1. MCU 上实现简单 Goertzel，每个码元窗口直接比较 4 个频点能量；
2. 或者为 mFSK 解调器建立一个累计缓冲，攒够 `fsk_get_nin()` 个采样再调用一次。

对于课程设计和 4 个固定频点，推荐方案 1，逻辑更可控，单片机实现也更简单。

### 2. HAL 回调还只是空壳

`audio_io.c` 里的 DMA 半满/满回调目前只是注释，没有真正切换缓冲区和调用用户回调。

上板时需要在全局保存 `AudioIO_Handle*`，并在：

```c
HAL_DAC_ConvHalfCpltCallbackCh1
HAL_DAC_ConvCpltCallbackCh1
HAL_ADC_ConvHalfCpltCallback
HAL_ADC_ConvCpltCallback
```

里切换缓冲区并调用 `tx_half_cb/tx_full_cb/rx_half_cb/rx_full_cb`。

### 3. 地址字段当前只能表示目标地址

当前协议 Address 字节是：

```text
高 4 位 = 目标地址
低 4 位 = 目标地址取反
```

因此接收回调中的 `src_addr` 实际上不是源地址。若后续做多终端通信，需要在帧里额外加入源地址字段。

## 建议下一步

1. 先运行 `tools/host_loopback_sim.py`，确认 PC 端软件链路 OK。
2. 上板前先写一个最小 TX 程序，只输出 `build_host` 中同样的 4FSK 音调序列。
3. 用示波器或 FFT 软件确认 DAC/PWM 输出的四个频点正确。
4. 接收端先不要跑完整协议，先每个码元输出判决出的 symbol 0-3。
5. 确认 symbol 序列能稳定恢复后，再接入 `proto_feed_symbol()`。
