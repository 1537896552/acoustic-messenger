/**
 * main.c - STM32 4FSK 音频通信示例
 *
 * 演示如何使用 4FSK 库在两块 STM32 开发板之间通过音频线通信。
 *
 * 硬件: STM32F4 Discovery / STM32F401 Nucleo 或其他 STM32 系列
 * 连接: 发送端 DAC(PA4) -> 接收端 ADC(PA0)
 *       两端共地
 *
 * 构建: 使用 STM32CubeIDE 或 CMake + arm-none-eabi-gcc
 */

#include "stm32_4fsk.h"
#include <stdio.h>
#include <string.h>

/* ---- 外部 HAL 句柄 (由 CubeMX 生成) ---- */
extern DAC_HandleTypeDef hdac;
extern ADC_HandleTypeDef hadc;
extern TIM_HandleTypeDef htim6;
extern TIM_HandleTypeDef htim2;
extern DMA_HandleTypeDef hdma_dac;
extern DMA_HandleTypeDef hdma_adc;

/* ---- 全局 4FSK 句柄 ---- */
static FSK4_Handle *fsk4;

/* 先用两个角色分开跑。发送板设为 1，接收板设为 0。 */
#define DEMO_ROLE_TX  1

/* ---- 接收回调 ---- */
static void on_data_received(uint8_t src_addr, const uint8_t *data,
                              uint32_t len, void *user) {
    (void)user;
    printf("RX from addr=%d [%lu bytes]: ", src_addr, len);
    for (uint32_t i = 0; i < len; i++) {
        printf("%02X ", data[i]);
    }
    printf("\n");
}

/* ---- 发送完成回调 ---- */
static void on_tx_done(void *user) {
    (void)user;
    printf("TX done\n");
}

/* ---- 错误回调 ---- */
static void on_error(int code, void *user) {
    (void)user;
    printf("Error: %d\n", code);
}

/* ---- 主函数 ---- */
int main(void) {
    /* 系统初始化 (CubeMX 生成) */
    HAL_Init();
    SystemClock_Config();

    /* 外设初始化 (CubeMX 生成) */
    MX_GPIO_Init();
    MX_DAC_Init();
    MX_ADC_Init();
    MX_TIM6_Init();
    MX_TIM2_Init();
    MX_DMA_Init();
    MX_USART2_UART_Init();

    printf("=== STM32 4FSK Audio Communication Demo ===\n");

    /* 1. 初始化 4FSK 调制解调器 (使用默认参数: 8kHz, 100baud) */
    fsk4 = fsk4_init(NULL, 0x01);  /* 本机地址=1 */
    if (!fsk4) {
        printf("FSK4 init failed!\n");
        return 1;
    }

    /* 2. 注入 HAL 句柄到音频 I/O 层 */
    fsk4_set_audio_handles(fsk4,
                           &hdac, &hadc,
                           &htim6, &htim2,
                           &hdma_dac, &hdma_adc);

    /* 3. 注册回调 */
    fsk4_set_rx_callback(fsk4, on_data_received, NULL);
    fsk4_set_tx_done_callback(fsk4, on_tx_done, NULL);
    fsk4_set_error_callback(fsk4, on_error, NULL);

#if DEMO_ROLE_TX
    /* 4A. 发送端：启动 DAC 发送通道 */
    if (fsk4_start_tx(fsk4) != 0) {
        printf("TX start failed!\n");
        return 1;
    }
    printf("Transmitter started...\n");

    /* 5A. 发送测试数据 */
    const char *test_msg = "Hello STM32 4FSK!";
    fsk4_send(fsk4, 0x02, (const uint8_t *)test_msg, strlen(test_msg));
#else
    /* 4B. 接收端：启动 ADC 接收通道 */
    if (fsk4_start_rx(fsk4) != 0) {
        printf("RX start failed!\n");
        return 1;
    }
    printf("Receiver started, listening...\n");
#endif

    /* 6. 主循环 */
    while (1) {
        /* 定期打印统计信息 */
        HAL_Delay(5000);

        FSK4_Stats stats;
        fsk4_get_stats(fsk4, &stats);
        printf("Stats: TX=%lu pkts, RX=%lu pkts, SNR=%.1f dB, "
               "Cksum err=%lu, FreqOff=%.1f Hz\n",
               stats.packets_sent, stats.packets_received,
               stats.snr_estimate, stats.crc_errors,
               stats.freq_offset);

#if DEMO_ROLE_TX
        /* 周期性发送测试帧 */
        if (!fsk4_is_busy(fsk4)) {
            static int counter = 0;
            char buf[64];
            int len = snprintf(buf, sizeof(buf),
                               "Periodic msg #%d from STM32 4FSK", counter++);
            fsk4_send(fsk4, 0x02, (const uint8_t *)buf, len);
        }
#endif
    }
}

/* ---- 系统时钟配置 (示例,根据实际板卡调整) ---- */
void SystemClock_Config(void) {
    /* 由 CubeMX 自动生成 */
}
