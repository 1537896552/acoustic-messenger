#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include "protocol.h"

#define SYSCLK_HZ          16000000UL
#define SAMPLE_RATE_HZ     8000UL
#define SAMPLE_PERIOD_US   (1000000UL / SAMPLE_RATE_HZ)
#define SYMBOL_MS          20UL
#define SYMBOL_SAMPLES     ((SAMPLE_RATE_HZ * SYMBOL_MS) / 1000UL)
#define TX_GAP_MS          120UL

#define LOCAL_ADDR         0x02U
#define DEST_ADDR          0x02U
#define RX_CONFIRM_TIMES   3U
#define TX_REPEAT_TIMES    3U

#define PI_F               3.14159265358979323846f

typedef struct {
    volatile uint32_t MODER;
    volatile uint32_t OTYPER;
    volatile uint32_t OSPEEDR;
    volatile uint32_t PUPDR;
    volatile uint32_t IDR;
    volatile uint32_t ODR;
    volatile uint32_t BSRR;
    volatile uint32_t LCKR;
    volatile uint32_t AFR[2];
} GPIO_TypeDef;

typedef struct {
    volatile uint32_t CR;
    volatile uint32_t PLLCFGR;
    volatile uint32_t CFGR;
    volatile uint32_t CIR;
    volatile uint32_t AHB1RSTR;
    volatile uint32_t AHB2RSTR;
    volatile uint32_t AHB3RSTR;
    uint32_t RESERVED0;
    volatile uint32_t APB1RSTR;
    volatile uint32_t APB2RSTR;
    uint32_t RESERVED1[2];
    volatile uint32_t AHB1ENR;
    volatile uint32_t AHB2ENR;
    volatile uint32_t AHB3ENR;
    uint32_t RESERVED2;
    volatile uint32_t APB1ENR;
    volatile uint32_t APB2ENR;
} RCC_TypeDef;

typedef struct {
    volatile uint32_t MEMRMP;
    volatile uint32_t PMC;
    volatile uint32_t EXTICR[4];
} SYSCFG_TypeDef;

typedef struct {
    volatile uint32_t IMR;
    volatile uint32_t EMR;
    volatile uint32_t RTSR;
    volatile uint32_t FTSR;
    volatile uint32_t SWIER;
    volatile uint32_t PR;
} EXTI_TypeDef;

typedef struct {
    volatile uint32_t SR;
    volatile uint32_t CR1;
    volatile uint32_t CR2;
    volatile uint32_t SMPR1;
    volatile uint32_t SMPR2;
    volatile uint32_t JOFR1;
    volatile uint32_t JOFR2;
    volatile uint32_t JOFR3;
    volatile uint32_t JOFR4;
    volatile uint32_t HTR;
    volatile uint32_t LTR;
    volatile uint32_t SQR1;
    volatile uint32_t SQR2;
    volatile uint32_t SQR3;
    volatile uint32_t JSQR;
    volatile uint32_t JDR1;
    volatile uint32_t JDR2;
    volatile uint32_t JDR3;
    volatile uint32_t JDR4;
    volatile uint32_t DR;
} ADC_TypeDef;

#define PERIPH_BASE        0x40000000UL
#define AHB1PERIPH_BASE    (PERIPH_BASE + 0x00020000UL)
#define APB2PERIPH_BASE    (PERIPH_BASE + 0x00010000UL)
#define GPIOA              ((GPIO_TypeDef *)(AHB1PERIPH_BASE + 0x0000UL))
#define GPIOB              ((GPIO_TypeDef *)(AHB1PERIPH_BASE + 0x0400UL))
#define RCC                ((RCC_TypeDef  *)(AHB1PERIPH_BASE + 0x3800UL))
#define ADC1               ((ADC_TypeDef  *)(APB2PERIPH_BASE + 0x2000UL))
#define SYSCFG             ((SYSCFG_TypeDef *)(APB2PERIPH_BASE + 0x3800UL))
#define EXTI               ((EXTI_TypeDef *)(APB2PERIPH_BASE + 0x3C00UL))

#define SYST_CSR           (*(volatile uint32_t *)0xE000E010UL)
#define SYST_RVR           (*(volatile uint32_t *)0xE000E014UL)
#define SYST_CVR           (*(volatile uint32_t *)0xE000E018UL)
#define NVIC_ISER0         (*(volatile uint32_t *)0xE000E100UL)
#define SCB_CPACR          (*(volatile uint32_t *)0xE000ED88UL)
#define DEMCR              (*(volatile uint32_t *)0xE000EDFCUL)
#define DWT_CTRL           (*(volatile uint32_t *)0xE0001000UL)
#define DWT_CYCCNT         (*(volatile uint32_t *)0xE0001004UL)

#define PIN_TX_OUT         0U     /* PB0: 4FSK square-wave output */
#define PIN_KEY            1U     /* PB1: pull-up input, falling edge sends 3 frames */
#define PIN_OLED_SCL       6U     /* PB6: OLED SCL */
#define PIN_OLED_SDA       7U     /* PB7: OLED SDA */

static volatile uint32_t g_ms;
static volatile uint8_t g_tx_request;
static uint8_t g_last_key = 1U;

static ProtoContext g_rx_proto;
static uint8_t g_tx_symbols[PROTO_MAX_FRAME_SYMS];
static uint8_t g_rx_payload[PROTO_MAX_PAYLOAD];
static uint8_t g_last_payload[PROTO_MAX_PAYLOAD];
static uint32_t g_last_len;
static uint8_t g_rx_same_count;
static float g_goertzel_coeff[4];

static const uint16_t g_tone_hz[4] = {1500U, 1650U, 1800U, 1950U};
static const uint8_t g_fixed_msg[] = "HELLO 4FSK";

void SystemInit(void);
void SysTick_Handler(void);
void EXTI1_IRQHandler(void);

static void delay_ms(uint32_t ms);
static void delay_us(uint32_t us);
static void board_init(void);
static void adc1_init_pa0(void);
static uint16_t adc1_read_pa0(void);
static void oled_init(void);
static void oled_clear(void);
static void oled_print_at(uint8_t page, uint8_t col, const char *text);
static void show_rx_screen(void);
static void send_three_frames(void);
static void rx_prepare_detector(void);
static uint8_t rx_detect_symbol(void);
static void rx_poll_once(void);

void SystemInit(void)
{
    SCB_CPACR |= (0xFU << 20); /* Enable FPU CP10/CP11. */
}

void SysTick_Handler(void)
{
    g_ms++;
}

void EXTI1_IRQHandler(void)
{
    if (EXTI->PR & (1UL << PIN_KEY)) {
        EXTI->PR = (1UL << PIN_KEY);
        if ((GPIOB->IDR & (1UL << PIN_KEY)) == 0U) {
            g_tx_request = 1U;
        }
    }
}

static void systick_init(void)
{
    SYST_RVR = (SYSCLK_HZ / 1000UL) - 1UL;
    SYST_CVR = 0;
    SYST_CSR = 0x07U;
}

static void dwt_init(void)
{
    DEMCR |= (1UL << 24);
    DWT_CYCCNT = 0;
    DWT_CTRL |= 1UL;
}

static void delay_ms(uint32_t ms)
{
    uint32_t start = g_ms;
    while ((uint32_t)(g_ms - start) < ms) {
        __asm("nop");
    }
}

static void delay_us(uint32_t us)
{
    uint32_t ticks = (SYSCLK_HZ / 1000000UL) * us;
    uint32_t start = DWT_CYCCNT;
    while ((uint32_t)(DWT_CYCCNT - start) < ticks) {
        __asm("nop");
    }
}

static void gpio_set(GPIO_TypeDef *port, uint32_t pin)
{
    port->BSRR = (1UL << pin);
}

static void gpio_reset(GPIO_TypeDef *port, uint32_t pin)
{
    port->BSRR = (1UL << (pin + 16U));
}

static void board_init(void)
{
    RCC->AHB1ENR |= (1UL << 0) | (1UL << 1);   /* GPIOA, GPIOB */
    RCC->APB2ENR |= (1UL << 8) | (1UL << 14);  /* ADC1, SYSCFG */

    /* PA0 = ADC1_IN0 analog input. */
    GPIOA->MODER &= ~(3UL << (0U * 2U));
    GPIOA->MODER |=  (3UL << (0U * 2U));
    GPIOA->PUPDR &= ~(3UL << (0U * 2U));

    /* PB0 = push-pull output for acoustic square-wave TX. */
    GPIOB->MODER &= ~(3UL << (PIN_TX_OUT * 2U));
    GPIOB->MODER |=  (1UL << (PIN_TX_OUT * 2U));
    GPIOB->OTYPER &= ~(1UL << PIN_TX_OUT);
    GPIOB->OSPEEDR |= (3UL << (PIN_TX_OUT * 2U));
    gpio_reset(GPIOB, PIN_TX_OUT);

    /* PB1 = pull-up key input, falling edge starts TX. */
    GPIOB->MODER &= ~(3UL << (PIN_KEY * 2U));
    GPIOB->PUPDR &= ~(3UL << (PIN_KEY * 2U));
    GPIOB->PUPDR |=  (1UL << (PIN_KEY * 2U));
    SYSCFG->EXTICR[0] &= ~(0xFUL << 4);
    SYSCFG->EXTICR[0] |=  (0x1UL << 4);        /* EXTI1 from port B. */
    EXTI->IMR  |= (1UL << PIN_KEY);
    EXTI->FTSR |= (1UL << PIN_KEY);
    EXTI->RTSR &= ~(1UL << PIN_KEY);
    NVIC_ISER0 = (1UL << 7);                   /* EXTI1_IRQn. */

    /* PB6/PB7 = open-drain GPIO for SSD1306 I2C. */
    GPIOB->MODER &= ~((3UL << (PIN_OLED_SCL * 2U)) |
                      (3UL << (PIN_OLED_SDA * 2U)));
    GPIOB->MODER |=  ((1UL << (PIN_OLED_SCL * 2U)) |
                      (1UL << (PIN_OLED_SDA * 2U)));
    GPIOB->OTYPER |= (1UL << PIN_OLED_SCL) | (1UL << PIN_OLED_SDA);
    GPIOB->OSPEEDR |= (3UL << (PIN_OLED_SCL * 2U)) |
                      (3UL << (PIN_OLED_SDA * 2U));
    GPIOB->PUPDR &= ~((3UL << (PIN_OLED_SCL * 2U)) |
                      (3UL << (PIN_OLED_SDA * 2U)));
    GPIOB->PUPDR |=  ((1UL << (PIN_OLED_SCL * 2U)) |
                      (1UL << (PIN_OLED_SDA * 2U)));
    gpio_set(GPIOB, PIN_OLED_SCL);
    gpio_set(GPIOB, PIN_OLED_SDA);
}

static void adc1_init_pa0(void)
{
    ADC1->CR1 = 0;
    ADC1->CR2 = 0;
    ADC1->SMPR2 &= ~(7UL << 0);
    ADC1->SMPR2 |=  (7UL << 0);  /* Long sample time on channel 0. */
    ADC1->SQR1 = 0;              /* One regular conversion. */
    ADC1->SQR3 = 0;              /* First conversion: channel 0 = PA0. */
    ADC1->CR2 |= 1UL;            /* ADON. */
    delay_ms(2);
}

static uint16_t adc1_read_pa0(void)
{
    ADC1->SR = 0;
    ADC1->CR2 |= (1UL << 30);    /* SWSTART. */
    while ((ADC1->SR & (1UL << 1)) == 0U) {
        __asm("nop");
    }
    return (uint16_t)(ADC1->DR & 0x0FFFU);
}

static void scl_high(void) { gpio_set(GPIOB, PIN_OLED_SCL); }
static void scl_low(void)  { gpio_reset(GPIOB, PIN_OLED_SCL); }
static void sda_high(void) { gpio_set(GPIOB, PIN_OLED_SDA); }
static void sda_low(void)  { gpio_reset(GPIOB, PIN_OLED_SDA); }

static void i2c_delay(void)
{
    delay_us(5);
}

static void i2c_start(void)
{
    sda_high();
    scl_high();
    i2c_delay();
    sda_low();
    i2c_delay();
    scl_low();
}

static void i2c_stop(void)
{
    sda_low();
    i2c_delay();
    scl_high();
    i2c_delay();
    sda_high();
    i2c_delay();
}

static void i2c_write_byte(uint8_t byte)
{
    for (uint8_t i = 0; i < 8U; i++) {
        if (byte & 0x80U) {
            sda_high();
        } else {
            sda_low();
        }
        i2c_delay();
        scl_high();
        i2c_delay();
        scl_low();
        byte <<= 1;
    }
    sda_high();                  /* Release for ACK. */
    i2c_delay();
    scl_high();
    i2c_delay();
    scl_low();
}

static void oled_write(uint8_t control, uint8_t value)
{
    i2c_start();
    i2c_write_byte(0x78U);       /* SSD1306 7-bit address 0x3C. */
    i2c_write_byte(control);
    i2c_write_byte(value);
    i2c_stop();
}

static void oled_cmd(uint8_t cmd)
{
    oled_write(0x00U, cmd);
}

static void oled_data(uint8_t data)
{
    oled_write(0x40U, data);
}

static void oled_set_pos(uint8_t page, uint8_t col)
{
    oled_cmd((uint8_t)(0xB0U | (page & 0x07U)));
    oled_cmd((uint8_t)(0x00U | (col & 0x0FU)));
    oled_cmd((uint8_t)(0x10U | ((col >> 4) & 0x0FU)));
}

static void oled_clear_page(uint8_t page)
{
    oled_set_pos(page, 0);
    for (uint8_t i = 0; i < 128U; i++) {
        oled_data(0x00U);
    }
}

static void oled_clear(void)
{
    for (uint8_t page = 0; page < 8U; page++) {
        oled_clear_page(page);
    }
}

static const uint8_t *glyph5x7(char c)
{
    static const uint8_t sp[5] = {0x00,0x00,0x00,0x00,0x00};
    static const uint8_t q[5]  = {0x02,0x01,0x51,0x09,0x06};
    static const uint8_t colon[5] = {0x00,0x36,0x36,0x00,0x00};
    static const uint8_t slash[5] = {0x20,0x10,0x08,0x04,0x02};
    static const uint8_t dash[5]  = {0x08,0x08,0x08,0x08,0x08};
    static const uint8_t d0[5] = {0x3E,0x51,0x49,0x45,0x3E};
    static const uint8_t d1[5] = {0x00,0x42,0x7F,0x40,0x00};
    static const uint8_t d2[5] = {0x42,0x61,0x51,0x49,0x46};
    static const uint8_t d3[5] = {0x21,0x41,0x45,0x4B,0x31};
    static const uint8_t d4[5] = {0x18,0x14,0x12,0x7F,0x10};
    static const uint8_t d5[5] = {0x27,0x45,0x45,0x45,0x39};
    static const uint8_t d6[5] = {0x3C,0x4A,0x49,0x49,0x30};
    static const uint8_t d7[5] = {0x01,0x71,0x09,0x05,0x03};
    static const uint8_t d8[5] = {0x36,0x49,0x49,0x49,0x36};
    static const uint8_t d9[5] = {0x06,0x49,0x49,0x29,0x1E};
    static const uint8_t A[5] = {0x7E,0x11,0x11,0x11,0x7E};
    static const uint8_t B[5] = {0x7F,0x49,0x49,0x49,0x36};
    static const uint8_t C[5] = {0x3E,0x41,0x41,0x41,0x22};
    static const uint8_t D[5] = {0x7F,0x41,0x41,0x22,0x1C};
    static const uint8_t E[5] = {0x7F,0x49,0x49,0x49,0x41};
    static const uint8_t F[5] = {0x7F,0x09,0x09,0x09,0x01};
    static const uint8_t G[5] = {0x3E,0x41,0x49,0x49,0x7A};
    static const uint8_t H[5] = {0x7F,0x08,0x08,0x08,0x7F};
    static const uint8_t I[5] = {0x00,0x41,0x7F,0x41,0x00};
    static const uint8_t J[5] = {0x20,0x40,0x41,0x3F,0x01};
    static const uint8_t K[5] = {0x7F,0x08,0x14,0x22,0x41};
    static const uint8_t L[5] = {0x7F,0x40,0x40,0x40,0x40};
    static const uint8_t M[5] = {0x7F,0x02,0x0C,0x02,0x7F};
    static const uint8_t N[5] = {0x7F,0x04,0x08,0x10,0x7F};
    static const uint8_t O[5] = {0x3E,0x41,0x41,0x41,0x3E};
    static const uint8_t P[5] = {0x7F,0x09,0x09,0x09,0x06};
    static const uint8_t Q[5] = {0x3E,0x41,0x51,0x21,0x5E};
    static const uint8_t R[5] = {0x7F,0x09,0x19,0x29,0x46};
    static const uint8_t S[5] = {0x46,0x49,0x49,0x49,0x31};
    static const uint8_t T[5] = {0x01,0x01,0x7F,0x01,0x01};
    static const uint8_t U[5] = {0x3F,0x40,0x40,0x40,0x3F};
    static const uint8_t V[5] = {0x1F,0x20,0x40,0x20,0x1F};
    static const uint8_t W[5] = {0x3F,0x40,0x38,0x40,0x3F};
    static const uint8_t X[5] = {0x63,0x14,0x08,0x14,0x63};
    static const uint8_t Y[5] = {0x07,0x08,0x70,0x08,0x07};
    static const uint8_t Z[5] = {0x61,0x51,0x49,0x45,0x43};

    if (c >= 'a' && c <= 'z') {
        c = (char)(c - 'a' + 'A');
    }
    switch (c) {
    case ' ': return sp;
    case '?': return q;
    case ':': return colon;
    case '/': return slash;
    case '-': return dash;
    case '0': return d0;
    case '1': return d1;
    case '2': return d2;
    case '3': return d3;
    case '4': return d4;
    case '5': return d5;
    case '6': return d6;
    case '7': return d7;
    case '8': return d8;
    case '9': return d9;
    case 'A': return A;
    case 'B': return B;
    case 'C': return C;
    case 'D': return D;
    case 'E': return E;
    case 'F': return F;
    case 'G': return G;
    case 'H': return H;
    case 'I': return I;
    case 'J': return J;
    case 'K': return K;
    case 'L': return L;
    case 'M': return M;
    case 'N': return N;
    case 'O': return O;
    case 'P': return P;
    case 'Q': return Q;
    case 'R': return R;
    case 'S': return S;
    case 'T': return T;
    case 'U': return U;
    case 'V': return V;
    case 'W': return W;
    case 'X': return X;
    case 'Y': return Y;
    case 'Z': return Z;
    default: return q;
    }
}

static void oled_putc(char c)
{
    const uint8_t *g = glyph5x7(c);
    for (uint8_t i = 0; i < 5U; i++) {
        oled_data(g[i]);
    }
    oled_data(0x00U);
}

static void oled_print_at(uint8_t page, uint8_t col, const char *text)
{
    oled_clear_page(page);
    oled_set_pos(page, col);
    while (*text != '\0') {
        oled_putc(*text++);
    }
}

static void oled_init(void)
{
    delay_ms(50);
    oled_cmd(0xAE);
    oled_cmd(0x20); oled_cmd(0x00);
    oled_cmd(0xB0);
    oled_cmd(0xC8);
    oled_cmd(0x00);
    oled_cmd(0x10);
    oled_cmd(0x40);
    oled_cmd(0x81); oled_cmd(0x7F);
    oled_cmd(0xA1);
    oled_cmd(0xA6);
    oled_cmd(0xA8); oled_cmd(0x3F);
    oled_cmd(0xA4);
    oled_cmd(0xD3); oled_cmd(0x00);
    oled_cmd(0xD5); oled_cmd(0x80);
    oled_cmd(0xD9); oled_cmd(0xF1);
    oled_cmd(0xDA); oled_cmd(0x12);
    oled_cmd(0xDB); oled_cmd(0x40);
    oled_cmd(0x8D); oled_cmd(0x14);
    oled_cmd(0xAF);
    oled_clear();
}

static void show_rx_screen(void)
{
    oled_print_at(0, 0, "4FSK TEST");
    oled_print_at(1, 0, "MODE: RX");
    oled_print_at(2, 0, "ADC: PA0");
    oled_print_at(3, 0, "WAIT FRAME");
}

static void rx_prepare_detector(void)
{
    for (uint8_t i = 0; i < 4U; i++) {
        float omega = 2.0f * PI_F * ((float)g_tone_hz[i] / (float)SAMPLE_RATE_HZ);
        g_goertzel_coeff[i] = 2.0f * cosf(omega);
    }
}

static uint8_t rx_detect_symbol(void)
{
    float q1[4] = {0, 0, 0, 0};
    float q2[4] = {0, 0, 0, 0};
    float power[4];
    uint32_t next_sample = DWT_CYCCNT;
    const uint32_t sample_step = SYSCLK_HZ / SAMPLE_RATE_HZ;

    for (uint32_t n = 0; n < SYMBOL_SAMPLES; n++) {
        while ((int32_t)(DWT_CYCCNT - next_sample) < 0) {
            __asm("nop");
        }
        next_sample += sample_step;

        float x = (float)((int32_t)adc1_read_pa0() - 2048);
        for (uint8_t k = 0; k < 4U; k++) {
            float q0 = g_goertzel_coeff[k] * q1[k] - q2[k] + x;
            q2[k] = q1[k];
            q1[k] = q0;
        }
    }

    uint8_t best = 0;
    float best_power = -1.0f;
    for (uint8_t k = 0; k < 4U; k++) {
        power[k] = (q1[k] * q1[k]) + (q2[k] * q2[k]) -
                   (g_goertzel_coeff[k] * q1[k] * q2[k]);
        if (power[k] > best_power) {
            best_power = power[k];
            best = k;
        }
    }
    return best;
}

static void tx_symbol(uint8_t sym)
{
    uint16_t freq = g_tone_hz[sym & 0x03U];
    uint32_t half_us = 500000UL / (uint32_t)freq;
    uint32_t end = DWT_CYCCNT + ((SYSCLK_HZ / 1000UL) * SYMBOL_MS);

    while ((int32_t)(DWT_CYCCNT - end) < 0) {
        gpio_set(GPIOB, PIN_TX_OUT);
        delay_us(half_us);
        gpio_reset(GPIOB, PIN_TX_OUT);
        delay_us(half_us);
    }
    gpio_reset(GPIOB, PIN_TX_OUT);
}

static void oled_print_tx_count(uint8_t index)
{
    char line[] = "MODE: TX 1/3";
    line[9] = (char)('1' + index);
    oled_print_at(1, 0, line);
}

static void send_frame_once(void)
{
    uint32_t n = proto_build_frame((ProtoContext *)0, DEST_ADDR,
                                   g_fixed_msg,
                                   (uint32_t)(sizeof(g_fixed_msg) - 1U),
                                   g_tx_symbols);
    for (uint32_t i = 0; i < n; i++) {
        tx_symbol(g_tx_symbols[i]);
    }
}

static void send_three_frames(void)
{
    oled_print_at(0, 0, "4FSK TEST");
    oled_print_at(2, 0, "MSG: HELLO");
    oled_print_at(3, 0, "PB0 OUTPUT");

    for (uint8_t i = 0; i < TX_REPEAT_TIMES; i++) {
        oled_print_tx_count(i);
        send_frame_once();
        delay_ms(TX_GAP_MS);
    }

    oled_print_at(1, 0, "MODE: TX OK");
    delay_ms(400);
    show_rx_screen();
    proto_reset(&g_rx_proto);
    g_rx_same_count = 0;
}

static bool same_payload(const uint8_t *data, uint32_t len)
{
    return (len == g_last_len) && (memcmp(data, g_last_payload, len) == 0);
}

static void update_rx_arbitration(const uint8_t *data, uint32_t len)
{
    if (same_payload(data, len)) {
        if (g_rx_same_count < RX_CONFIRM_TIMES) {
            g_rx_same_count++;
        }
    } else {
        memcpy(g_last_payload, data, len);
        g_last_len = len;
        g_rx_same_count = 1U;
    }

    if (g_rx_same_count >= RX_CONFIRM_TIMES) {
        oled_print_at(1, 0, "MODE: RX OK");
        oled_print_at(2, 0, "RX SAME 3/3");
        oled_print_at(3, 0, "MSG: HELLO");
        g_rx_same_count = 0;
        g_last_len = 0;
    } else {
        char line[] = "RX SAME 1/3";
        line[8] = (char)('0' + g_rx_same_count);
        oled_print_at(2, 0, line);
    }
}

static void rx_poll_once(void)
{
    uint8_t src = 0;
    uint32_t len = 0;
    uint8_t sym = rx_detect_symbol();

    if (proto_feed_symbol(&g_rx_proto, sym, &src, g_rx_payload, &len)) {
        (void)src;
        update_rx_arbitration(g_rx_payload, len);
        proto_reset(&g_rx_proto);
    }
}

int main(void)
{
    systick_init();
    dwt_init();
    board_init();
    adc1_init_pa0();
    oled_init();
    rx_prepare_detector();
    proto_init(&g_rx_proto, LOCAL_ADDR, 12U);
    show_rx_screen();

    for (;;) {
        uint8_t key_now = (GPIOB->IDR & (1UL << PIN_KEY)) ? 1U : 0U;
        if ((g_last_key != 0U) && (key_now == 0U)) {
            g_tx_request = 1U;
        }
        g_last_key = key_now;

        if (g_tx_request != 0U) {
            g_tx_request = 0U;
            send_three_frames();
            while ((GPIOB->IDR & (1UL << PIN_KEY)) == 0U) {
                delay_ms(5);
            }
            g_last_key = 1U;
        } else if (key_now != 0U) {
            rx_poll_once();
        } else {
            delay_ms(5);
        }
    }
}
