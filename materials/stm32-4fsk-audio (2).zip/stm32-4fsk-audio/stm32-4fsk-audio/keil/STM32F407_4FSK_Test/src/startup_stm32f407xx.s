; Minimal startup file for STM32F407VG, Keil ARMASM syntax.

Stack_Size      EQU     0x00000800

                AREA    STACK, NOINIT, READWRITE, ALIGN=3
Stack_Mem       SPACE   Stack_Size
__initial_sp

                PRESERVE8
                THUMB

                AREA    RESET, DATA, READONLY
                EXPORT  __Vectors
                EXPORT  __Vectors_End
                EXPORT  __Vectors_Size

                IMPORT  SysTick_Handler
                IMPORT  EXTI1_IRQHandler

__Vectors       DCD     __initial_sp
                DCD     Reset_Handler
                DCD     NMI_Handler
                DCD     HardFault_Handler
                DCD     MemManage_Handler
                DCD     BusFault_Handler
                DCD     UsageFault_Handler
                DCD     0
                DCD     0
                DCD     0
                DCD     0
                DCD     SVC_Handler
                DCD     DebugMon_Handler
                DCD     0
                DCD     PendSV_Handler
                DCD     SysTick_Handler

                ; External IRQ 0..7. EXTI1 is IRQ number 7.
                DCD     Default_Handler      ; WWDG
                DCD     Default_Handler      ; PVD
                DCD     Default_Handler      ; TAMP_STAMP
                DCD     Default_Handler      ; RTC_WKUP
                DCD     Default_Handler      ; FLASH
                DCD     Default_Handler      ; RCC
                DCD     Default_Handler      ; EXTI0
                DCD     EXTI1_IRQHandler     ; EXTI1

                ; The remaining vectors are left as defaults.
                REPT    90
                DCD     Default_Handler
                ENDR

__Vectors_End
__Vectors_Size  EQU     __Vectors_End - __Vectors

                AREA    |.text|, CODE, READONLY

Reset_Handler   PROC
                EXPORT  Reset_Handler
                IMPORT  SystemInit
                IMPORT  main
                BL      SystemInit
                BL      main
                B       .
                ENDP

Default_Handler PROC
                EXPORT  NMI_Handler              [WEAK]
                EXPORT  HardFault_Handler        [WEAK]
                EXPORT  MemManage_Handler        [WEAK]
                EXPORT  BusFault_Handler         [WEAK]
                EXPORT  UsageFault_Handler       [WEAK]
                EXPORT  SVC_Handler              [WEAK]
                EXPORT  DebugMon_Handler         [WEAK]
                EXPORT  PendSV_Handler           [WEAK]
                EXPORT  Default_Handler          [WEAK]
NMI_Handler
HardFault_Handler
MemManage_Handler
BusFault_Handler
UsageFault_Handler
SVC_Handler
DebugMon_Handler
PendSV_Handler
                B       .
                ENDP

                ALIGN
                END
