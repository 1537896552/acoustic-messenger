$ErrorActionPreference = "Stop"

$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectFile = Join-Path $ProjectDir "Keil_STM32F407_4FSK_Test.uvprojx"
$LogFile = Join-Path $ProjectDir "build.log"

$candidates = @()

foreach ($root in @("C:\Keil_v5", "C:\Keil", "D:\Keil_v5", "D:\Keil")) {
    $path = Join-Path $root "UV4\UV4.exe"
    if (Test-Path $path) {
        $candidates += $path
    }
}

$pathHits = (Get-Command "UV4.exe" -ErrorAction SilentlyContinue)
if ($pathHits) {
    $candidates += $pathHits.Source
}

$uv4 = $candidates | Select-Object -First 1
if (-not $uv4) {
    Write-Host "Keil UV4.exe was not found in common install paths or PATH."
    Write-Host "Open the project manually in Keil uVision:"
    Write-Host "  $ProjectFile"
    exit 2
}

Push-Location $ProjectDir
try {
    Write-Host "Using Keil:"
    Write-Host "  $uv4"
    Write-Host "Building:"
    Write-Host "  $ProjectFile"
    & $uv4 -b $ProjectFile -o $LogFile
    $code = $LASTEXITCODE
    Write-Host "Keil exit code: $code"
    Write-Host "Build log:"
    Write-Host "  $LogFile"
    exit $code
}
finally {
    Pop-Location
}
