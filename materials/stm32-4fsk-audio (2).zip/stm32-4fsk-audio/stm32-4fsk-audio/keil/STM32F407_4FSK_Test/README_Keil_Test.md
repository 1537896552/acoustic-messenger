# STM32F407 4FSK Keil Test Project

This is a Keil MDK bare-metal bring-up project for the acoustic 4FSK link.
It reuses `src/protocol.c` from the repo, then implements the hardware test
logic directly in `src/main.c`.

## Assumed MCU

- STM32F407VG
- Keil MDK / uVision project: `Keil_STM32F407_4FSK_Test.uvprojx`
- System clock: default HSI 16 MHz, no external crystal required for this first test

If your board is not STM32F407VG, create a new Keil target with the exact chip
and add these same source files.

## Pin Map

| Function | STM32 Pin | Note |
| --- | --- | --- |
| OLED SCL | PB6 | Bit-banged I2C, SSD1306 address 0x3C |
| OLED SDA | PB7 | Bit-banged I2C, SSD1306 address 0x3C |
| TX output | PB0 | 4FSK square-wave output |
| RX input | PA0 | ADC1_IN0, connect after receiver amplifier/filter |
| Mode key | PB1 | Internal pull-up, press/connect to GND for falling edge TX |

## Behavior

- PB1 high: receive mode. OLED shows `MODE: RX`.
- PB1 falling edge: send the fixed payload `HELLO 4FSK` three times.
- TX uses PB0 square wave:
  - symbol 0: 1500 Hz
  - symbol 1: 1650 Hz
  - symbol 2: 1800 Hz
  - symbol 3: 1950 Hz
- RX samples PA0 at about 8 kHz and uses a four-bin Goertzel detector.
- RX arbitration accepts data only after the same payload is received 3 times.

## Hardware Test Steps

1. Connect OLED:
   - PB6 -> SCL
   - PB7 -> SDA
   - VCC/GND according to your OLED module
2. Connect PB1 with a button or jumper to GND. PB1 is internally pulled up.
3. For single-board waveform checking, observe PB0 with an oscilloscope or FFT.
4. For receiver checking, feed the amplifier output to PA0.
5. For full communication, use one board as sender and another board as receiver,
   or wire PB0 through the acoustic/electrical receive path into PA0 on the other board.

## Build

Open the `.uvprojx` file in Keil uVision and press Build, or run:

```powershell
.\build_with_keil.ps1
```

The output hex is expected at:

```text
Objects\STM32F407_4FSK_Test.hex
```

## Notes

- This project intentionally avoids CubeMX/HAL so it can be tested before the
  final hardware project is generated.
- The signal path is square-wave 4FSK for easy classroom verification with FFT.
- Once the board, crystal, and exact chip are finalized, the same logic can be
  moved into a normal HAL/CubeMX project.
