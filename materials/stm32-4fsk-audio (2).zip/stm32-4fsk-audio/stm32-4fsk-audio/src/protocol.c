/**
 * protocol.c - 4FSK 音频通信协议层实现
 *
 * MIT License. Copyright (c) 2024
 *
 * 帧格式:
 *   Preamble(16sym) + Sync(2B) + Address(1B) + Length(1B) + Data(N B) + Cksum(1B)
 *
 * Address 编码: 高4位=地址, 低4位=地址按位取反
 *   - 发送时将地址组装为 (addr<<4) | (~addr & 0x0F)
 *   - 接收时验证高4位与低4位互为取反,不匹配则丢弃
 *
 * 校验和: Address + Length + Data 各字节累加,取低8位
 */

#include "protocol.h"
#include <string.h>

void proto_init(ProtoContext *ctx, uint8_t addr, uint8_t match_min) {
    memset(ctx, 0, sizeof(*ctx));
    ctx->state = PROTO_STATE_IDLE;
    ctx->expected_addr = addr;
    ctx->preamble_match_min = (match_min > 0 && match_min <= 16) ? match_min : 12;
}

uint32_t proto_get_frame_size(uint32_t payload_len) {
    if (payload_len > PROTO_MAX_PAYLOAD) return 0;
    return PROTO_PREAMBLE_SYMS + ((PROTO_OVERHEAD + payload_len) * 4);
}

/* ---- 发送 ---- */

static void emit_byte_symbols(uint8_t byte, uint8_t *out, uint32_t *pos) {
    /* MSB first: 7654 3210 -> sym0 sym1 sym2 sym3 */
    out[(*pos)++] = (byte >> 6) & 0x03;
    out[(*pos)++] = (byte >> 4) & 0x03;
    out[(*pos)++] = (byte >> 2) & 0x03;
    out[(*pos)++] = byte & 0x03;
}

uint32_t proto_build_frame(ProtoContext *ctx, uint8_t dst_addr,
                           const uint8_t *data, uint32_t len,
                           uint8_t *out) {
    (void)ctx;
    if (len > PROTO_MAX_PAYLOAD) return 0;

    uint32_t pos = 0;
    uint8_t cksum = 0;

    /* 1. 前导码: 交替 0x0 / 0x3 */
    for (int i = 0; i < PROTO_PREAMBLE_SYMS; i++) {
        out[pos++] = (i & 1) ? 0x03 : 0x00;
    }

    /* 2. 同步字 0xA5 0xF0 */
    emit_byte_symbols(0xA5, out, &pos);
    emit_byte_symbols(0xF0, out, &pos);

    /* 3. 地址: 高4位=地址, 低4位=~地址 */
    uint8_t addr_byte = (uint8_t)(((dst_addr << 4) & 0xF0) |
                                  ((~dst_addr) & 0x0F));
    emit_byte_symbols(addr_byte, out, &pos);
    cksum += addr_byte;

    /* 4. 长度 */
    emit_byte_symbols((uint8_t)len, out, &pos);
    cksum += (uint8_t)len;

    /* 5. 数据 */
    for (uint32_t i = 0; i < len; i++) {
        emit_byte_symbols(data[i], out, &pos);
        cksum += data[i];
    }

    /* 6. 校验和 */
    emit_byte_symbols(cksum, out, &pos);

    return pos;
}

/* ---- 接收: 将4个2bit符号拼成1个字节 ---- */

static bool symbols_to_byte(ProtoContext *ctx, uint8_t sym, uint8_t *byte_out) {
    /* 每符号2bit, 先到先存高位 (MSB first) */
    ctx->current_byte = (uint8_t)((ctx->current_byte << 2) | (sym & 0x03));
    ctx->bits_in_byte += 2;

    if (ctx->bits_in_byte >= 8) {
        *byte_out = ctx->current_byte;
        ctx->current_byte = 0;
        ctx->bits_in_byte = 0;
        return true;
    }
    return false;
}

/* ---- 接收状态机 ---- */

bool proto_feed_symbol(ProtoContext *ctx, uint8_t sym,
                       uint8_t *addr, uint8_t *out, uint32_t *len) {
    sym &= 0x03;

    switch (ctx->state) {

    case PROTO_STATE_IDLE:
        ctx->rx_pos = 0;
        ctx->current_byte = 0;
        ctx->bits_in_byte = 0;
        ctx->preamble_ring_idx = 0;
        ctx->preamble_matches  = 0;
        memset(ctx->preamble_ring, 0xFF, sizeof(ctx->preamble_ring));
        ctx->state = PROTO_STATE_PREAMBLE;
        /* fall through */

    /* ---- 前导码检测 (滑动窗口容错匹配) ---- */
    case PROTO_STATE_PREAMBLE: {
        /* 期待模式: 偶数位置=0x0, 奇数位置=0x3 */
        uint8_t pos_in_win = ctx->preamble_ring_idx & 0x0F;
        uint8_t expected = (pos_in_win & 1) ? 0x03 : 0x00;

        /* 移出旧符号: 如果旧符号之前是匹配的,匹配计数减1 */
        uint8_t old_sym = ctx->preamble_ring[pos_in_win];
        uint8_t old_expected = (pos_in_win & 1) ? 0x03 : 0x00;
        if (old_sym == old_expected && old_sym != 0xFF) {
            ctx->preamble_matches--;
        }

        /* 写入新符号 */
        ctx->preamble_ring[pos_in_win] = sym;
        if (sym == expected) {
            ctx->preamble_matches++;
        }

        ctx->preamble_ring_idx++;
        ctx->rx_pos++;

        /* 窗口填满后,检查匹配数是否达到门限 */
        if (ctx->rx_pos >= PROTO_PREAMBLE_SYMS) {
            if (ctx->preamble_matches >= ctx->preamble_match_min) {
                ctx->state = PROTO_STATE_SYNC;
                ctx->rx_pos = 0;
                ctx->current_byte = 0;
                ctx->bits_in_byte = 0;
            }
            /* 未达门限则继续滑动窗口,等待下一符号 */
        }
        break;
    }

    /* ---- 字节字段接收 ---- */
    case PROTO_STATE_SYNC:
    case PROTO_STATE_ADDRESS:
    case PROTO_STATE_LENGTH:
    case PROTO_STATE_DATA:
    case PROTO_STATE_CHECKSUM: {
        uint8_t byte_val;
        if (!symbols_to_byte(ctx, sym, &byte_val)) {
            break; /* 还没凑够一个字节 */
        }

        switch (ctx->state) {

        case PROTO_STATE_SYNC:
            ctx->rx_buf[ctx->rx_pos++] = byte_val;
            if (ctx->rx_pos == 2) {
                uint16_t sync = ((uint16_t)ctx->rx_buf[0] << 8) | ctx->rx_buf[1];
                if (sync != PROTO_SYNC_WORD) {
                    proto_reset(ctx);
                    return false;
                }
                ctx->state = PROTO_STATE_ADDRESS;
                ctx->rx_pos = 0;
            }
            break;

        case PROTO_STATE_ADDRESS: {
            uint8_t hi = (byte_val >> 4) & 0x0F;
            uint8_t lo = byte_val & 0x0F;
            /* 高4位与低4位必须互为按位取反 */
            if (((hi ^ lo) & 0x0F) != 0x0F) {
                proto_reset(ctx);
                return false;
            }
            /* 地址过滤 */
            if (ctx->expected_addr != 0xFF && hi != ctx->expected_addr) {
                proto_reset(ctx);
                return false;
            }
            ctx->rx_buf[0] = byte_val;
            ctx->state = PROTO_STATE_LENGTH;
            break;
        }

        case PROTO_STATE_LENGTH:
            ctx->rx_total_len = byte_val;
            if (ctx->rx_total_len == 0 ||
                ctx->rx_total_len > PROTO_MAX_PAYLOAD) {
                proto_reset(ctx);
                return false;
            }
            ctx->rx_buf[1] = byte_val;
            ctx->rx_pos = 0;
            ctx->state = PROTO_STATE_DATA;
            break;

        case PROTO_STATE_DATA:
            ctx->rx_buf[2 + ctx->rx_pos] = byte_val;
            ctx->rx_pos++;
            if (ctx->rx_pos >= ctx->rx_total_len) {
                ctx->state = PROTO_STATE_CHECKSUM;
            }
            break;

        case PROTO_STATE_CHECKSUM: {
            /* 校验: Address + Length + Data 累加 */
            uint8_t calc = 0;
            calc += ctx->rx_buf[0];                     /* Address */
            calc += ctx->rx_buf[1];                     /* Length */
            for (uint32_t i = 0; i < ctx->rx_total_len; i++) {
                calc += ctx->rx_buf[2 + i];             /* Data */
            }

            if (calc == byte_val) {
                *addr = (ctx->rx_buf[0] >> 4) & 0x0F;
                memcpy(out, &ctx->rx_buf[2], ctx->rx_total_len);
                *len = ctx->rx_total_len;
                ctx->state = PROTO_STATE_IDLE;
                return true;
            }
            proto_reset(ctx);
            return false;
        }

        default:
            break;
        }
        break;
    }

    default:
        break;
    }

    return false;
}

void proto_reset(ProtoContext *ctx) {
    ctx->state = PROTO_STATE_IDLE;
    ctx->rx_pos = 0;
    ctx->current_byte = 0;
    ctx->bits_in_byte = 0;
    ctx->preamble_matches = 0;
    ctx->preamble_ring_idx = 0;
}

uint8_t proto_checksum(const uint8_t *data, uint32_t len) {
    uint8_t sum = 0;
    for (uint32_t i = 0; i < len; i++) {
        sum += data[i];
    }
    return sum;
}
