/**
 * stm32_4fsk.c - STM32 4FSK Audio Communication 核心实现
 *
 * MIT License. Copyright (c) 2024
 *
 * 架构:
 *   发送路径: 用户数据 -> protocol_build_frame() -> modulate() -> DAC DMA
 *   接收路径: ADC DMA -> fsk_demod() -> proto_feed_symbol() -> 用户回调
 *
 * 依赖:
 *   lib/mfsk/   (LGPL-2.1) — 4FSK 调制解调算法核心
 *   src/protocol.{h,c}       — 帧协议层
 *   src/audio_io.{h,c}       — STM32 音频 I/O 层
 */

#include "stm32_4fsk.h"
#include "protocol.h"
#include "audio_io.h"
#include "fsk.h"
#include "modulator.h"
#include "demodulator.h"

#include <stdlib.h>
#include <string.h>
#include <math.h>

/* ================================================================
 * 内部结构
 * ================================================================ */

struct FSK4_Handle {
    /* 配置 */
    FSK4_Config   config;
    FSK4_Mode     mode;

    /* mFSK 库句柄 */
    struct FSK      *fsk;
    struct MODULATE *mod;

    /* 协议层 */
    ProtoContext   proto;

    /* 音频 I/O */
    AudioIO_Handle audio;

    /* 发送缓冲区 */
    uint8_t   tx_frame[PROTO_MAX_FRAME_SYMS]; /* 组装好的帧 (每个元素=1个4FSK符号) */
    uint32_t  tx_frame_len;                /* 帧长度 (符号数) */
    uint32_t  tx_sym_pos;                  /* 当前发送到的符号位置 */
    int16_t   tx_samples[FSK_DAC_BUFFER_SIZE]; /* 调制后的PCM样本 */

    /* 接收缓冲区 */
    int16_t   rx_samples[FSK_ADC_BUFFER_SIZE]; /* ADC采集的PCM样本 */
    complex float rx_complex[FSK_ADC_BUFFER_SIZE]; /* 复数样本(用于mFSK) */
    uint8_t   rx_bits[PROTO_MAX_FRAME_SYMS * 2];  /* 解调出的bits */
    uint8_t   rx_payload[PROTO_MAX_PAYLOAD]; /* 解码后的负载数据 */

    /* 回调 */
    FSK4_RxCallback     rx_cb;
    FSK4_TxDoneCallback tx_done_cb;
    FSK4_ErrorCallback  err_cb;
    void               *rx_user_data;
    void               *tx_user_data;
    void               *err_user_data;

    /* 统计 */
    FSK4_Stats  stats;

    /* 静噪 */
    uint16_t squelch_threshold;     /* ADC 幅值门限 */
    uint8_t  preamble_match_min;    /* 前导码最低匹配数 */

    /* 发送状态 */
    bool tx_active;
};

/* ================================================================
 * 默认配置
 * ================================================================ */

static const FSK4_Config default_config = {
    .sample_rate       = FSK_SAMPLE_RATE,
    .symbol_rate       = FSK_SYMBOL_RATE,
    .first_freq        = FSK_FIRST_FREQ,
    .freq_shift        = FSK_FREQ_SHIFT,
    .squelch_threshold = FSK_SQUELCH_THRESHOLD,
    .preamble_match_min = FSK_PREAMBLE_MATCH_MIN,
};

/* ================================================================
 * 内部辅助函数
 * ================================================================ */

/** 将 int16_t PCM 样本转换为 mFSK 的 complex float 格式 */
static void pcm_to_complex(const int16_t *pcm, complex float *cx, int n) {
    for (int i = 0; i < n; i++) {
        /* 归一化到 [-1, 1] */
        cx[i] = (float)pcm[i] / 32768.0f + 0.0f * I;
    }
}

/** 将 complex float 调制输出转换为 int16_t PCM */
static void complex_to_pcm(const complex float *cx, int16_t *pcm, int n,
                           float amplitude) {
    for (int i = 0; i < n; i++) {
        float val = crealf(cx[i]) * amplitude;
        /* 限幅 */
        if (val > 32767.0f)  val = 32767.0f;
        if (val < -32768.0f) val = -32768.0f;
        pcm[i] = (int16_t)val;
    }
}

/** 将一个字节拆分为 4 个 4FSK 符号 (每符号2bit) */
static void byte_to_symbols(uint8_t byte, uint8_t *syms) {
    syms[0] = (byte >> 6) & 0x03;
    syms[1] = (byte >> 4) & 0x03;
    syms[2] = (byte >> 2) & 0x03;
    syms[3] = byte & 0x03;
}

/**
 * 计算交流信号峰值幅度 (相对于直流中点)
 *
 * ADC 输入信号叠加在 Vdda/2 (1.65V, ADC=2048) 直流偏置上。
 * audio_io 层已去除直流,因此 samples 以 0 为中心:
 *   int16 = 0   → 1.65V (直流中点)
 *   int16 > 0   → 高于 1.65V
 *   int16 < 0   → 低于 1.65V
 *
 * 返回峰值幅度 (int16 绝对值),对应 ADC 原始摆动范围。
 * 例: 0.1V 交流峰值 → 0.1/3.3×4096 = 124 ADC → 124×16 ≈ 1984
 */
static uint16_t calc_ac_amplitude(const int16_t *samples, int count) {
    int32_t max_val = 0;
    for (int i = 0; i < count; i++) {
        int32_t abs_val = samples[i] > 0 ? samples[i] : -samples[i];
        if (abs_val > max_val) max_val = abs_val;
    }
    return (uint16_t)max_val;
}

/** 处理接收数据 (从 ADC 缓冲区取出,能量检测,解调,提取帧) */
static void process_rx_data(FSK4_Handle *h, const int16_t *samples, int count) {
    /* 交流信号幅度检测: 峰值低于门限视为无效信号,跳过解调避免噪声误触发 */
    if (h->squelch_threshold > 0) {
        uint16_t ampl = calc_ac_amplitude(samples, count);
        if (ampl < h->squelch_threshold) {
            return; /* 信号太弱 (噪声或静音),丢弃 */
        }
    }

    int Ts = fsk_get_Ts(h->fsk);

    /* 逐符号处理,滑动窗口 */
    for (int offset = 0; offset < count; offset += Ts) {
        int remaining = count - offset;
        int block_size = (remaining >= Ts) ? Ts : remaining;

        /* 转换为复数并解调 */
        pcm_to_complex(&samples[offset], h->rx_complex, block_size);

        /* 调用 mFSK 解调 */
        fsk_demod(h->fsk, h->rx_bits, h->rx_complex);

        int nbits = fsk_get_Nbits(h->fsk);

        /* 将解调出的 bits 送入协议层状态机 */
        for (int b = 0; b < nbits; b += 2) {
            uint8_t sym = (h->rx_bits[b + 1] & 0x01) |
                          ((h->rx_bits[b] & 0x01) << 1);

            uint8_t src_addr = 0;
            uint32_t payload_len = 0;
            if (proto_feed_symbol(&h->proto, sym,
                                  &src_addr, h->rx_payload, &payload_len)) {
                h->stats.packets_received++;
                h->stats.bytes_received += payload_len;

                if (h->rx_cb) {
                    h->rx_cb(src_addr, h->rx_payload, payload_len, h->rx_user_data);
                }
            }
        }
    }
}

/** 填充下一块 DAC 发送数据 */
static int fill_tx_buffer(FSK4_Handle *h) {
    if (!h->tx_active || h->tx_sym_pos >= h->tx_frame_len) {
        /* 发送完成 */
        h->tx_active = false;
        if (h->tx_done_cb) {
            h->tx_done_cb(h->tx_user_data);
        }
        return 0;
    }

    int cycles = h->mod->cycles; /* Ts = sample_rate / symbol_rate */
    int buf_size = FSK_DAC_BUFFER_SIZE;
    int sample_pos = 0;

    while (sample_pos + cycles <= buf_size &&
           h->tx_sym_pos < h->tx_frame_len) {
        /* 获取下一个符号,调制为音频样本 */
        uint8_t sym = h->tx_frame[h->tx_sym_pos] & 0x03;
        complex float baseband[cycles];
        modulate(h->mod, baseband, sym);

        /* 转换为 PCM (50% 幅度) */
        for (int i = 0; i < cycles; i++) {
            int16_t val = (int16_t)(crealf(baseband[i]) * 16384.0f);
            h->tx_samples[sample_pos++] = val;
        }

        h->tx_sym_pos++;
    }

    /* 写入音频 I/O 缓冲区 */
    return audio_io_write_tx_buffer(&h->audio, h->tx_samples, sample_pos);
}

/* ================================================================
 * DAC DMA 半完成/完成回调 (在中断上下文中调用)
 * ================================================================ */

static void on_tx_half_done(void *user_data) {
    /* 可以在这里填充前半部分缓冲区 */
}

static void on_tx_done(void *user_data) {
    FSK4_Handle *h = (FSK4_Handle *)user_data;
    fill_tx_buffer(h);
}

/* ================================================================
 * ADC DMA 半完成/完成回调
 * ================================================================ */

static void on_rx_half_done(void *user_data) {
    FSK4_Handle *h = (FSK4_Handle *)user_data;
    int half = AUDIO_ADC_BUF_SIZE / 2;
    process_rx_data(h, &h->rx_samples[0], half);
}

static void on_rx_done(void *user_data) {
    FSK4_Handle *h = (FSK4_Handle *)user_data;
    int half = AUDIO_ADC_BUF_SIZE / 2;
    process_rx_data(h, &h->rx_samples[half], half);
}

/* ================================================================
 * 公共 API
 * ================================================================ */

FSK4_Handle* fsk4_init(const FSK4_Config *config, uint8_t my_addr) {
    FSK4_Handle *h = (FSK4_Handle *)calloc(1, sizeof(FSK4_Handle));
    if (!h) return NULL;

    /* 使用默认配置或用户配置 */
    if (config) {
        h->config = *config;
    } else {
        h->config = default_config;
    }

    /* 创建 mFSK 调制器 */
    h->mod = mod_create(MODE_4FSK,
                         h->config.sample_rate,
                         h->config.symbol_rate,
                         h->config.first_freq,
                         h->config.freq_shift);
    if (!h->mod) {
        free(h);
        return NULL;
    }

    /* 创建 mFSK 解调器 (高码率模式) */
    h->fsk = fsk_create_hbr(h->config.sample_rate,
                            h->config.symbol_rate,
                            OVERSAMPLE_RATE,
                            MODE_4FSK,
                            h->config.first_freq,
                            h->config.freq_shift);
    if (!h->fsk) {
        mod_destroy(h->mod);
        free(h);
        return NULL;
    }

    /* 保存静噪参数 */
    h->squelch_threshold  = h->config.squelch_threshold;
    h->preamble_match_min = h->config.preamble_match_min;

    /* 初始化协议层 */
    proto_init(&h->proto, my_addr, h->preamble_match_min);

    /* 初始化音频 I/O */
    if (audio_io_init(&h->audio, h->config.sample_rate) != 0) {
        fsk_destroy(h->fsk);
        mod_destroy(h->mod);
        free(h);
        return NULL;
    }

    /* 注册音频回调 */
    h->audio.tx_half_cb = on_tx_half_done;
    h->audio.tx_full_cb = on_tx_done;
    h->audio.rx_half_cb = on_rx_half_done;
    h->audio.rx_full_cb = on_rx_done;
    h->audio.user_data  = h;

    h->mode = FSK4_MODE_IDLE;
    return h;
}

void fsk4_deinit(FSK4_Handle *h) {
    if (!h) return;
    fsk4_stop(h);
    audio_io_deinit(&h->audio);
    fsk_destroy(h->fsk);
    mod_destroy(h->mod);
    free(h);
}

int fsk4_set_audio_handles(FSK4_Handle *h,
                           void *hdac, void *hadc,
                           void *htim_dac, void *htim_adc,
                           void *hdma_dac, void *hdma_adc) {
    if (!h) return -1;

    h->audio.hdac     = (DAC_HandleTypeDef *)hdac;
    h->audio.hadc     = (ADC_HandleTypeDef *)hadc;
    h->audio.htim_dac = (TIM_HandleTypeDef *)htim_dac;
    h->audio.htim_adc = (TIM_HandleTypeDef *)htim_adc;
    h->audio.hdma_dac = (DMA_HandleTypeDef *)hdma_dac;
    h->audio.hdma_adc = (DMA_HandleTypeDef *)hdma_adc;
    return 0;
}

void fsk4_set_rx_callback(FSK4_Handle *h, FSK4_RxCallback cb, void *user_data) {
    h->rx_cb = cb;
    h->rx_user_data = user_data;
}

void fsk4_set_tx_done_callback(FSK4_Handle *h, FSK4_TxDoneCallback cb,
                                void *user_data) {
    h->tx_done_cb = cb;
    h->tx_user_data = user_data;
}

void fsk4_set_error_callback(FSK4_Handle *h, FSK4_ErrorCallback cb,
                              void *user_data) {
    h->err_cb = cb;
    h->err_user_data = user_data;
}

int fsk4_start_tx(FSK4_Handle *h) {
    if (h->mode != FSK4_MODE_IDLE) return -1;
    return audio_io_start_tx(&h->audio);
}

int fsk4_start_rx(FSK4_Handle *h) {
    if (h->mode != FSK4_MODE_IDLE) return -1;
    h->mode = FSK4_MODE_RX;
    return audio_io_start_rx(&h->audio);
}

int fsk4_stop(FSK4_Handle *h) {
    audio_io_stop_tx(&h->audio);
    audio_io_stop_rx(&h->audio);
    h->mode = FSK4_MODE_IDLE;
    h->tx_active = false;
    proto_reset(&h->proto);
    return 0;
}

int fsk4_send(FSK4_Handle *h, uint8_t dst_addr, const uint8_t *data, uint32_t len) {
    if (h->tx_active) return -1;    /* 忙 */
    if (len > FSK_MAX_PAYLOAD_SIZE) return -2;

    /* 组装帧 */
    uint32_t frame_len = proto_build_frame(&h->proto, dst_addr, data, len, h->tx_frame);
    if (frame_len == 0) return -3;

    h->tx_frame_len = frame_len;
    h->tx_sym_pos = 0;
    h->tx_active = true;

    /* 启动发送 */
    fill_tx_buffer(h);
    h->stats.packets_sent++;
    h->stats.bytes_sent += len;

    return 0;
}

void fsk4_get_stats(FSK4_Handle *h, FSK4_Stats *stats) {
    /* 从 mFSK 获取实时的 SNR 和频偏估计 */
    h->stats.snr_estimate = stats_get_snr_est(h->fsk->stats);
    h->stats.freq_offset  = stats_get_foff(h->fsk->stats);
    h->stats.clock_offset_ppm = stats_get_clock_offset(h->fsk->stats);
    *stats = h->stats;
}

void fsk4_reset_stats(FSK4_Handle *h) {
    memset(&h->stats, 0, sizeof(h->stats));
}

FSK4_Mode fsk4_get_mode(FSK4_Handle *h) {
    return h->mode;
}

bool fsk4_is_busy(FSK4_Handle *h) {
    return h->tx_active;
}

void fsk4_set_squelch(FSK4_Handle *h, uint16_t threshold) {
    h->squelch_threshold = threshold;
}
