#!/usr/bin/env python3
"""PC-side 4FSK loopback test.

This script does not use STM32 HAL.  It verifies the software chain:

    payload -> protocol symbols -> 4FSK waveform -> Goertzel demod
            -> protocol parser -> recovered payload

Run from the repository root:

    python tools/host_loopback_sim.py
    python tools/host_loopback_sim.py --snr-db -6 --freq-offset-hz 5
"""

from __future__ import annotations

import argparse
import math
import wave
from dataclasses import dataclass
from pathlib import Path

import numpy as np


PROTO_SYNC_WORD = 0xA5F0
PROTO_PREAMBLE_SYMS = 16
PROTO_MAX_PAYLOAD = 48
PROTO_OVERHEAD = 5


@dataclass
class FSK4Config:
    sample_rate: int = 8000
    symbol_rate: int = 100
    first_freq: float = 1500.0
    freq_shift: float = 150.0
    amplitude: float = 0.82

    @property
    def samples_per_symbol(self) -> int:
        if self.sample_rate % self.symbol_rate != 0:
            raise ValueError("sample_rate must be divisible by symbol_rate")
        return self.sample_rate // self.symbol_rate

    @property
    def tones(self) -> list[float]:
        return [self.first_freq + i * self.freq_shift for i in range(4)]


def byte_to_symbols(byte: int) -> list[int]:
    return [
        (byte >> 6) & 0x03,
        (byte >> 4) & 0x03,
        (byte >> 2) & 0x03,
        byte & 0x03,
    ]


def symbols_to_byte(symbols: list[int]) -> int:
    value = 0
    for sym in symbols:
        value = ((value << 2) | (sym & 0x03)) & 0xFF
    return value


def build_frame(dst_addr: int, payload: bytes) -> list[int]:
    if len(payload) > PROTO_MAX_PAYLOAD:
        raise ValueError(f"payload too long: {len(payload)} > {PROTO_MAX_PAYLOAD}")

    symbols: list[int] = []
    for i in range(PROTO_PREAMBLE_SYMS):
        symbols.append(0x03 if i & 1 else 0x00)

    symbols += byte_to_symbols((PROTO_SYNC_WORD >> 8) & 0xFF)
    symbols += byte_to_symbols(PROTO_SYNC_WORD & 0xFF)

    addr_byte = ((dst_addr << 4) & 0xF0) | ((~dst_addr) & 0x0F)
    checksum = addr_byte
    symbols += byte_to_symbols(addr_byte)

    checksum = (checksum + len(payload)) & 0xFF
    symbols += byte_to_symbols(len(payload))

    for b in payload:
        checksum = (checksum + b) & 0xFF
        symbols += byte_to_symbols(b)

    symbols += byte_to_symbols(checksum)
    return symbols


class ProtocolParser:
    def __init__(self, expected_addr: int = 0xFF, preamble_match_min: int = 12):
        self.expected_addr = expected_addr
        self.preamble_match_min = preamble_match_min
        self.reset()

    def reset(self) -> None:
        self.state = "preamble"
        self.preamble: list[int] = []
        self.byte_syms: list[int] = []
        self.rx: list[int] = []
        self.length = 0

    def _push_byte_symbol(self, sym: int) -> int | None:
        self.byte_syms.append(sym & 0x03)
        if len(self.byte_syms) < 4:
            return None
        value = symbols_to_byte(self.byte_syms)
        self.byte_syms.clear()
        return value

    def feed(self, sym: int) -> tuple[int, bytes] | None:
        sym &= 0x03

        if self.state == "preamble":
            self.preamble.append(sym)
            if len(self.preamble) > PROTO_PREAMBLE_SYMS:
                self.preamble.pop(0)
            if len(self.preamble) == PROTO_PREAMBLE_SYMS:
                matches = sum(
                    1 for i, s in enumerate(self.preamble)
                    if s == (0x03 if i & 1 else 0x00)
                )
                if matches >= self.preamble_match_min:
                    self.state = "sync"
                    self.rx.clear()
                    self.byte_syms.clear()
            return None

        value = self._push_byte_symbol(sym)
        if value is None:
            return None

        if self.state == "sync":
            self.rx.append(value)
            if len(self.rx) == 2:
                sync = (self.rx[0] << 8) | self.rx[1]
                if sync != PROTO_SYNC_WORD:
                    self.reset()
                else:
                    self.state = "address"
                    self.rx.clear()
            return None

        if self.state == "address":
            hi = (value >> 4) & 0x0F
            lo = value & 0x0F
            if ((hi ^ lo) & 0x0F) != 0x0F:
                self.reset()
                return None
            if self.expected_addr != 0xFF and hi != self.expected_addr:
                self.reset()
                return None
            self.rx = [value]
            self.state = "length"
            return None

        if self.state == "length":
            if value == 0 or value > PROTO_MAX_PAYLOAD:
                self.reset()
                return None
            self.length = value
            self.rx.append(value)
            self.state = "data"
            return None

        if self.state == "data":
            self.rx.append(value)
            if len(self.rx) == 2 + self.length:
                self.state = "checksum"
            return None

        if self.state == "checksum":
            calc = sum(self.rx) & 0xFF
            if calc == value:
                addr = (self.rx[0] >> 4) & 0x0F
                payload = bytes(self.rx[2:])
                self.reset()
                return addr, payload
            self.reset()
            return None

        self.reset()
        return None


def modulate(symbols: list[int], cfg: FSK4Config, freq_offset_hz: float = 0.0) -> np.ndarray:
    n = cfg.samples_per_symbol
    out = np.zeros(n * len(symbols), dtype=np.float64)
    phase = 0.0
    ramp = max(1, min(n // 4, int(0.002 * cfg.sample_rate)))
    env = np.ones(n, dtype=np.float64)
    if ramp > 1:
        r = 0.5 - 0.5 * np.cos(np.linspace(0.0, math.pi, ramp))
        env[:ramp] = r
        env[-ramp:] = r[::-1]

    t = np.arange(n) / cfg.sample_rate
    tones = cfg.tones
    for i, sym in enumerate(symbols):
        freq = tones[sym & 0x03] + freq_offset_hz
        seg = np.sin(phase + 2.0 * math.pi * freq * t)
        phase = (phase + 2.0 * math.pi * freq * n / cfg.sample_rate) % (2.0 * math.pi)
        out[i * n:(i + 1) * n] = cfg.amplitude * seg * env
    return out


def add_awgn(x: np.ndarray, snr_db: float | None, rng: np.random.Generator) -> np.ndarray:
    if snr_db is None:
        return x
    power = float(np.mean(x * x))
    noise_power = power / (10.0 ** (snr_db / 10.0))
    return x + rng.normal(0.0, math.sqrt(noise_power), len(x))


def demodulate_goertzel(samples: np.ndarray, cfg: FSK4Config) -> list[int]:
    n = cfg.samples_per_symbol
    frames = samples[: (len(samples) // n) * n].reshape(-1, n)
    t = np.arange(n) / cfg.sample_rate
    refs = []
    for f in cfg.tones:
        refs.append((np.sin(2.0 * math.pi * f * t), np.cos(2.0 * math.pi * f * t)))

    decoded: list[int] = []
    for frame in frames:
        energies = []
        for sref, cref in refs:
            i = float(np.dot(frame, sref))
            q = float(np.dot(frame, cref))
            energies.append(i * i + q * q)
        decoded.append(int(np.argmax(energies)))
    return decoded


def save_wav(path: Path, samples: np.ndarray, sample_rate: int) -> None:
    pcm = np.clip(samples * 32767.0, -32768, 32767).astype("<i2")
    with wave.open(str(path), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(pcm.tobytes())


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--message", default="Hello STM32 4FSK!")
    parser.add_argument("--dst-addr", type=lambda s: int(s, 0), default=0x02)
    parser.add_argument("--expected-addr", type=lambda s: int(s, 0), default=0x02)
    parser.add_argument("--sample-rate", type=int, default=8000)
    parser.add_argument("--symbol-rate", type=int, default=100)
    parser.add_argument("--first-freq", type=float, default=1500.0)
    parser.add_argument("--freq-shift", type=float, default=150.0)
    parser.add_argument("--snr-db", type=float, default=None)
    parser.add_argument("--freq-offset-hz", type=float, default=0.0)
    parser.add_argument("--seed", type=int, default=20260703)
    parser.add_argument("--wav", type=Path, default=Path("build_host/tx_4fsk.wav"))
    args = parser.parse_args()

    cfg = FSK4Config(
        sample_rate=args.sample_rate,
        symbol_rate=args.symbol_rate,
        first_freq=args.first_freq,
        freq_shift=args.freq_shift,
    )
    payload = args.message.encode("utf-8")
    symbols = build_frame(args.dst_addr, payload)
    tx = modulate(symbols, cfg, freq_offset_hz=args.freq_offset_hz)
    rx = add_awgn(tx, args.snr_db, np.random.default_rng(args.seed))
    decoded_symbols = demodulate_goertzel(rx, cfg)

    parser_state = ProtocolParser(expected_addr=args.expected_addr)
    result = None
    for sym in decoded_symbols:
        result = parser_state.feed(sym)
        if result is not None:
            break

    args.wav.parent.mkdir(parents=True, exist_ok=True)
    save_wav(args.wav, tx, cfg.sample_rate)

    print("=== 4FSK host loopback ===")
    print(f"tones          : {', '.join(f'{f:.1f}' for f in cfg.tones)} Hz")
    print(f"sample/symbol  : {cfg.samples_per_symbol}")
    print(f"payload bytes  : {len(payload)}")
    print(f"frame symbols  : {len(symbols)}")
    print(f"duration       : {len(tx) / cfg.sample_rate:.3f} s")
    print(f"wav            : {args.wav}")

    symbol_errors = sum(a != b for a, b in zip(symbols, decoded_symbols))
    print(f"symbol errors  : {symbol_errors}/{len(symbols)}")

    if result is None:
        print("RX             : FAIL (no valid frame)")
        return 1

    addr, recovered = result
    ok = recovered == payload
    print(f"RX addr        : 0x{addr:X}")
    print(f"RX payload     : {recovered!r}")
    print(f"RX             : {'OK' if ok else 'FAIL'}")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
